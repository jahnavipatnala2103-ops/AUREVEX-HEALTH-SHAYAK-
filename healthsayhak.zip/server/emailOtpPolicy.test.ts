import { describe, expect, it } from "vitest";
import { hashEmailCode, matchesEmailCode, normalizeAuthEmail, otpRetryAfterSeconds } from "./emailOtpPolicy";

describe("email OTP policy", () => {
  it("normalizes case and whitespace", () => {
    expect(normalizeAuthEmail("  Patient@Example.COM ")).toBe("patient@example.com");
  });

  it("stores a keyed digest rather than the code itself", () => {
    const digest = hashEmailCode("patient@example.com", "274913", "test-secret");
    expect(digest).toMatch(/^[0-9a-f]{64}$/);
    expect(digest).not.toContain("274913");
    expect(matchesEmailCode("patient@example.com", "274913", "test-secret", digest)).toBe(true);
  });

  it("binds the code digest to both the email and server secret", () => {
    const digest = hashEmailCode("patient@example.com", "274913", "secret-a");
    expect(matchesEmailCode("other@example.com", "274913", "secret-a", digest)).toBe(false);
    expect(matchesEmailCode("patient@example.com", "274913", "secret-b", digest)).toBe(false);
    expect(matchesEmailCode("patient@example.com", "000000", "secret-a", digest)).toBe(false);
  });

  it("enforces a one-minute resend cooldown", () => {
    const now = new Date("2026-10-08T10:00:00.000Z");
    expect(otpRetryAfterSeconds([new Date(now.getTime() - 15_000)], now)).toBe(45);
  });

  it("enforces a maximum of five codes per rolling hour", () => {
    const now = new Date("2026-10-08T10:00:00.000Z");
    const times = [10, 20, 30, 40, 50].map(minutes => new Date(now.getTime() - minutes * 60_000));
    expect(otpRetryAfterSeconds(times, now)).toBe(600);
    expect(otpRetryAfterSeconds(times.slice(1), now)).toBe(0);
  });

  it("reports the longer hourly wait when requests also hit the one-minute cooldown", () => {
    const now = new Date("2026-10-08T10:00:00.000Z");
    const times = [10, 20, 30, 40, 50].map(seconds => new Date(now.getTime() - seconds * 1000));
    expect(otpRetryAfterSeconds(times, now)).toBe(3_550);
  });
});
