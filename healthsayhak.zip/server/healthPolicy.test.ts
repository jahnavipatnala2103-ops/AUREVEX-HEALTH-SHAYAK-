import { describe, expect, it } from "vitest";
import { authorizedRecordKinds, isContextualHealthFollowUp, isHealthRelatedQuestion, promptSourceRegistry, resolveCitations } from "./healthPolicy";
import type { CopilotSource } from "../shared/health";

describe("health access and citation policy", () => {
  it("limits an Appointments grant to appointment records, not consultations", () => {
    expect(authorizedRecordKinds(["appointments"])).toEqual(["appointment"]);
    expect(authorizedRecordKinds(["appointments"])).not.toContain("encounter");
  });

  it("combines only the selected record categories", () => {
    expect(new Set(authorizedRecordKinds(["appointments", "medications"]))).toEqual(new Set(["appointment", "medication"]));
    expect(authorizedRecordKinds(["timeline"])).toEqual([]);
  });

  it("gives the model exact server-assigned source IDs without exposing document IDs", () => {
    const sources: CopilotSource[] = [{ id: 44, title: "Blood Test Report", date: "2026-10-08", kind: "observation", documentId: 91 }];
    expect(promptSourceRegistry(sources)).toEqual([{ id: 44, title: "Blood Test Report", date: "2026-10-08", kind: "observation" }]);
  });

  it("rebuilds citation metadata from trusted sources and ignores invalid or duplicate IDs", () => {
    const sources: CopilotSource[] = [
      { id: 44, title: "Blood Test Report", date: "2026-10-08", kind: "observation", documentId: 91 },
      { id: -7, title: "Follow up with doctor", date: "date not recorded", kind: "follow-up task" },
    ];
    const result = resolveCitations([
      { id: 44, title: "Invented title", date: "1900-01-01", kind: "appointment" },
      { id: -7, title: "Invented task", date: "1900-01-01", kind: "report" },
      { id: 404, title: "Unknown", date: "", kind: "report" },
      { id: 44, title: "Duplicate", date: "", kind: "report" },
    ], sources);
    expect(result).toEqual([sources[0], sources[1]]);
  });

  it("allows explicit health questions in supported languages and blocks general trivia", () => {
    expect(isHealthRelatedQuestion("What does my latest blood report mean?" )).toBe(true);
    expect(isHealthRelatedQuestion("నా రక్త పరీక్ష ఏమి చూపిస్తోంది?" )).toBe(true);
    expect(isHealthRelatedQuestion("मेरी दवा क्या है?" )).toBe(true);
    expect(isHealthRelatedQuestion("Who is Virat Kohli?" )).toBe(false);
    expect(isHealthRelatedQuestion("Tell me about cricket" )).toBe(false);
  });

  it("accepts only tightly-scoped pronoun follow-ups, never an unrelated named person", () => {
    expect(isContextualHealthFollowUp("What about it?" )).toBe(true);
    expect(isContextualHealthFollowUp("क्या यह सुरक्षित है?" )).toBe(true);
    expect(isContextualHealthFollowUp("What about Virat Kohli?" )).toBe(false);
  });
});
