import type { AccessScope, CopilotSource, HealthRecordKind } from "../shared/health";

export type PromptSource = Pick<CopilotSource, "id" | "title" | "date" | "kind">;

const healthTopicPattern = /\b(?:health|medical|doctor|nurse|clinic|hospital|report|lab|test(?: result)?|blood|glucose|hemoglobin|haemoglobin|pressure|cholesterol|medicat\w*|prescription|dose|dosage|tablet|pill|allerg\w*|symptom\w*|fever|pain|sick|ill|unwell|cough|headache|dizz\w*|nausea|rash|appointment|consultation|visit|follow.?up|insurance|emergency|diagnos\w*|condition|disease|surgery|vaccine|wellness|health record|next step)\b|\bwhat (?:should|do) i (?:do )?next\b|ఆరోగ్య|వైద్య|డాక్టర్|ఆసుపత్రి|నివేదిక|రిపోర్ట్|ల్యాబ్|రక్త|పరీక్ష|గ్లూకోజ్|హిమోగ్లోబిన్|మందు|మందులు|ప్రిస్క్రిప్షన్|మోతాదు|అలర్జీ|లక్షణ|జ్వరం|నొప్పి|దగ్గు|తలనొప్పి|అపాయింట్|సందర్శన|ఫాలో.?అప్|భీమా|అత్యవసర|శస్త్రచికిత్స|టీకా|ఆరోగ్య రికార్డు|తదుపరి అడుగు|स्वास्थ्य|चिकित्सा|डॉक्टर|अस्पताल|रिपोर्ट|लैब|खून|रक्त|जाँच|जांच|परिणाम|ग्लूकोज|हीमोग्लोबिन|दवा|दवाइ|प्रिस्क्रिप्शन|खुराक|एलर्जी|लक्षण|बुखार|दर्द|खांसी|सिरदर्द|चक्कर|अपॉइंटमेंट|परामर्श|फॉलो.?अप|बीमा|आपातकाल|सर्जरी|टीका|स्वास्थ्य रिकॉर्ड|अगला कदम/iu;

/** Only explicit health-topic questions may reach the model. */
export function isHealthRelatedQuestion(question: string): boolean {
  return healthTopicPattern.test(question.normalize("NFKC"));
}

/** Permit only short pronoun references in a chat that already contains a health question. */
export function isContextualHealthFollowUp(question: string): boolean {
  const normalized = question.normalize("NFKC").toLowerCase().trim().replace(/[?!.,。؟]+$/u, "").replace(/\s+/g, " ");
  return /^(?:what about (?:it|this|that)|what does (?:it|this|that) mean|does (?:it|this|that) mean|is (?:it|this|that) (?:normal|safe|serious)|can i take (?:it|this)|should i take (?:it|this)|why is (?:it|that) happening|ఇది (?:ఏమి|ఎలా|సాధారణమా)|అది (?:ఏమి|ఎలా|సాధారణమా)|దాని గురించి (?:ఏమిటి|చెప్పండి)|इसे लेकर (?:क्या|कैसा)|क्या यह (?:सामान्य|सुरक्षित)(?: है)?|इसका क्या मतलब|क्यों ऐसा हो रहा)$/.test(normalized);
}

/** Map only explicitly selected categories to record kinds. Timeline access is event-only. */
export function authorizedRecordKinds(scopes: readonly AccessScope[]): HealthRecordKind[] {
  const allowed = new Set<HealthRecordKind>();
  if (scopes.includes("reports")) { allowed.add("observation"); allowed.add("wellness"); }
  if (scopes.includes("medications")) allowed.add("medication");
  // Consultations are not appointments; only a separate Timeline grant can expose their events.
  if (scopes.includes("appointments")) allowed.add("appointment");
  return [...allowed];
}

/** Send exact server-assigned citations to the model without any file access identifier. */
export function promptSourceRegistry(sources: readonly CopilotSource[]): PromptSource[] {
  return sources.map(({ id, title, date, kind }) => ({ id, title, date, kind }));
}

/** Accept model-selected IDs only, then rebuild every displayed field from trusted server data. */
export function resolveCitations(candidates: readonly PromptSource[], registry: readonly CopilotSource[]): CopilotSource[] {
  const approved = new Map(registry.map(source => [source.id, source]));
  const used = new Set<number>();
  return candidates.flatMap(candidate => {
    const source = approved.get(candidate.id);
    if (!source || used.has(source.id)) return [];
    used.add(source.id);
    return [source];
  });
}
