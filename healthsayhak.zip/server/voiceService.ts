import type { HealthLanguage } from "@shared/health";

const allowedAudioTypes = new Set(["audio/webm", "audio/ogg", "audio/mp4", "audio/wav", "audio/mpeg"]);
const maximumBytes = 8 * 1024 * 1024;

function hasExpectedSignature(bytes: Buffer, mimeType: string): boolean {
  if (mimeType === "audio/webm") return bytes.length >= 4 && bytes.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]));
  if (mimeType === "audio/ogg") return bytes.length >= 4 && bytes.subarray(0, 4).toString("ascii") === "OggS";
  if (mimeType === "audio/wav") return bytes.length >= 12 && bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WAVE";
  if (mimeType === "audio/mp4") return bytes.length >= 8 && bytes.subarray(4, 8).toString("ascii") === "ftyp";
  if (mimeType === "audio/mpeg") return bytes.length >= 3 && (bytes.subarray(0, 3).toString("ascii") === "ID3" || (bytes[0] === 0xff && (bytes[1]! & 0xe0) === 0xe0));
  return false;
}

export async function transcribeVoice(input: { base64: string; mimeType: string; language: HealthLanguage }) {
  const mimeType = input.mimeType.split(";")[0]!.trim().toLowerCase();
  if (!allowedAudioTypes.has(mimeType)) throw new Error("This audio format is not supported. Try speaking again or type your question.");
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input.base64)) throw new Error("The recording could not be read. Try again or type your question.");
  const bytes = Buffer.from(input.base64, "base64");
  if (!bytes.length || bytes.length > maximumBytes || !hasExpectedSignature(bytes, mimeType)) throw new Error("The recording could not be validated. Make a short new recording or type your question.");

  const apiUrl = process.env.MANUS_API_URL?.replace(/\/+$/, "");
  const apiKey = process.env.MANUS_API_KEY;
  if (!apiUrl || !apiKey) throw new Error("Voice transcription is temporarily unavailable. You can type your question instead.");

  const form = new FormData();
  const extension = mimeType === "audio/webm" ? "webm" : mimeType === "audio/ogg" ? "ogg" : mimeType === "audio/mp4" ? "m4a" : mimeType === "audio/wav" ? "wav" : "mp3";
  form.append("file", new Blob([bytes], { type: mimeType }), `health-question.${extension}`);
  form.append("model", "whisper-1");
  const languageName = input.language === "te" ? "Telugu" : input.language === "hi" ? "Hindi" : "English";
  form.append("prompt", `Transcribe the user's spoken health question. The expected language is ${languageName}. Preserve medical names and numbers as spoken; do not answer the question.`);

  let response: Response;
  try {
    response = await fetch(`${apiUrl}/v1/audio/transcriptions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}` },
      body: form,
      signal: AbortSignal.timeout(45_000),
    });
  } catch {
    throw new Error("Voice transcription is temporarily unavailable. You can type your question instead.");
  }

  let payload: unknown;
  try { payload = await response.json(); } catch { payload = null; }
  const body = payload && typeof payload === "object" ? payload as { text?: unknown; error?: unknown } : {};
  if (!response.ok || body.error) throw new Error("Voice transcription is temporarily unavailable. Please try once more or type your question.");
  const text = typeof body.text === "string" ? body.text.trim() : "";
  if (!text) throw new Error("No speech was detected. Try again or type your question.");
  return { text: text.slice(0, 1600) };
}
