import { createCanvas, DOMMatrix, ImageData, Path2D } from "@napi-rs/canvas";
import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

export type HealthDocumentPreview = {
  mimeType: "image/jpeg" | "image/png";
  bytes: Buffer;
};

const MAX_PREVIEW_PAGES = 3;
const MAX_PREVIEW_BYTES = 1_500_000;
const MAX_PREVIEW_WIDTH = 1440;
const MAX_PREVIEW_HEIGHT = 1600;

// PDF.js uses these web-platform classes when rendering in Node. The explicit canvas
// implementation avoids relying on a browser worker or external URL.
if (typeof globalThis.DOMMatrix === "undefined") Object.assign(globalThis, { DOMMatrix });
if (typeof globalThis.ImageData === "undefined") Object.assign(globalThis, { ImageData });
if (typeof globalThis.Path2D === "undefined") Object.assign(globalThis, { Path2D });

export async function renderPdfHealthPreviews(bytes: Buffer): Promise<HealthDocumentPreview[]> {
  const loadingTask = getDocument({
    data: new Uint8Array(bytes),
    useSystemFonts: true,
    stopAtErrors: true,
    maxImageSize: MAX_PREVIEW_WIDTH * MAX_PREVIEW_HEIGHT,
    canvasMaxAreaInBytes: MAX_PREVIEW_WIDTH * MAX_PREVIEW_HEIGHT * 4,
  });

  try {
    const pdf = await loadingTask.promise;
    const previews: HealthDocumentPreview[] = [];
    const pageCount = Math.min(pdf.numPages, MAX_PREVIEW_PAGES);
    for (let pageNumber = 1; pageNumber <= pageCount; pageNumber++) {
      const page = await pdf.getPage(pageNumber);
      const original = page.getViewport({ scale: 1 });
      const scale = Math.min(1.4, MAX_PREVIEW_WIDTH / original.width, MAX_PREVIEW_HEIGHT / original.height);
      const viewport = page.getViewport({ scale });
      const canvas = createCanvas(Math.max(1, Math.ceil(viewport.width)), Math.max(1, Math.ceil(viewport.height)));
      await page.render({ canvas: canvas as unknown as HTMLCanvasElement, viewport }).promise;
      const previewBytes = canvas.toBuffer("image/jpeg", 0.68);
      if (!previewBytes.length || previewBytes.length > MAX_PREVIEW_BYTES) {
        throw new Error("PDF preview page exceeded its safe size limit.");
      }
      previews.push({ mimeType: "image/jpeg", bytes: Buffer.from(previewBytes) });
      page.cleanup();
      canvas.width = 0;
      canvas.height = 0;
    }
    if (!previews.length) throw new Error("The PDF has no pages to check.");
    return previews;
  } catch {
    // Do not include file contents or PDF parser details in user-visible errors or logs.
    throw new Error("health_document_preview_failed");
  } finally {
    await loadingTask.destroy().catch(() => undefined);
  }
}
