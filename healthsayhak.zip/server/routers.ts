import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  askCopilot,
  confirmDocument,
  createAppointment,
  createPendingDocument,
  getAuthorizedDocumentDataUrl,
  getConversationHistory,
  getOverview,
  completeOnboarding,
  removeHealthDocument,
  getSharedRecords,
  listCareGrants,
  revokeCareGrant,
  saveCareGrant,
  toggleTask,
  updateProfile,
} from "./healthService";
import { z } from "zod";
import { transcribeVoice } from "./voiceService";
import { onboardingInputSchema } from "./onboardingPolicy";
import { requestEmailCode, verifyEmailCode } from "./emailAuth";

const language = z.enum(["en", "te", "hi"]);
const observation = z.object({
  test: z.string().max(180), value: z.string().max(100), unit: z.string().max(80),
  referenceRange: z.string().max(180), outsideRange: z.union([z.boolean(), z.null()]), sourceText: z.string().max(500),
});
const medication = z.object({
  name: z.string().max(180), dosage: z.string().max(160), frequency: z.string().max(160), instructions: z.string().max(300),
  duration: z.string().max(160), prescribedBy: z.string().max(180), sourceText: z.string().max(500),
});
const extracted = z.object({
  kind: z.enum(["lab_report", "prescription", "doctor_note", "discharge_summary", "insurance", "medical_record", "wellness", "other"]),
  title: z.string().max(255), documentDate: z.string().max(60), provider: z.string().max(200),
  observations: z.array(observation).max(100), medications: z.array(medication).max(50),
  symptoms: z.array(z.string().max(200)).max(30), assessments: z.array(z.string().max(200)).max(30),
  recommendations: z.array(z.string().max(300)).max(30), diagnoses: z.array(z.string().max(200)).max(30),
  procedures: z.array(z.string().max(200)).max(30), admissionDate: z.string().max(60), dischargeDate: z.string().max(60),
  followUpInstructions: z.array(z.string().max(300)).max(30), insuranceProvider: z.string().max(180),
  policyInformation: z.string().max(600), importantFindings: z.array(z.string().max(400)).max(30),
  whatThisMeans: z.string().max(1600), sourceNote: z.string().max(400), confidenceNote: z.string().max(400),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    requestEmailCode: publicProcedure.input(z.object({ email: z.string().email().max(320) })).mutation(({ input }) => requestEmailCode(input.email)),
    verifyEmailCode: publicProcedure.input(z.object({ email: z.string().email().max(320), code: z.string().regex(/^\d{6}$/) })).mutation(({ ctx, input }) => verifyEmailCode(input.email, input.code, ctx.req, ctx.res)),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  health: router({
    overview: protectedProcedure.query(({ ctx }) => getOverview(ctx.user.id, ctx.user.name ?? "HealthSahayak member")),
    completeOnboarding: protectedProcedure.input(onboardingInputSchema).mutation(({ ctx, input }) => completeOnboarding(ctx.user.id, ctx.user.name ?? "HealthSahayak member", input)),
    updateProfile: protectedProcedure.input(z.object({
      displayName: z.string().max(180).optional(), dateOfBirth: z.string().max(10).optional(), gender: z.string().max(80).optional(), bloodGroup: z.string().max(16).optional(), preferredLanguage: language.optional(),
      allergies: z.array(z.string().max(120)).max(30).optional(), conditions: z.array(z.string().max(120)).max(30).optional(), importantInformation: z.string().max(2000).optional(),
      emergencyName: z.string().max(160).optional(), emergencyPhone: z.string().max(48).optional(), emergencyInformation: z.string().max(1000).optional(),
      insuranceProvider: z.string().max(180).optional(), policyInformation: z.string().max(600).optional(), policyDates: z.string().max(160).optional(),
    })).mutation(({ ctx, input }) => updateProfile(ctx.user.id, input)),
    toggleTask: protectedProcedure.input(z.object({ id: z.number().int().positive(), completed: z.boolean() })).mutation(({ ctx, input }) => toggleTask(ctx.user.id, input.id, input.completed)),
    createAppointment: protectedProcedure.input(z.object({ provider: z.string().max(180).optional(), startsAt: z.string().min(1).max(40), status: z.enum(["Upcoming", "Completed", "Cancelled"]), notes: z.string().max(500).optional() })).mutation(({ ctx, input }) => createAppointment(ctx.user.id, input)),
  }),
  documents: router({
    analyze: protectedProcedure.input(z.object({
      fileName: z.string().min(1).max(255),
      mimeType: z.enum(["application/pdf", "image/jpeg", "image/png"]),
      base64: z.string().min(1).max(12_000_000),
      language,
      consentAccepted: z.literal(true),
    })).mutation(async ({ ctx, input }) => {
      const cleaned = input.base64.replace(/^data:[^;]+;base64,/, "");
      if (!/^[A-Za-z0-9+/]*={0,2}$/.test(cleaned)) throw new Error("This file could not be read. Please select a PDF, JPG or PNG.");
      const bytes = Buffer.from(cleaned, "base64");
      if (!bytes.length || bytes.length > 8 * 1024 * 1024) throw new Error("Choose a file smaller than 8 MB.");
      const matchesMime = input.mimeType === "application/pdf" ? bytes.subarray(0, 5).toString("ascii") === "%PDF-"
        : input.mimeType === "image/png" ? bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
        : bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
      if (!matchesMime) throw new Error("The file contents do not match the selected PDF, JPG or PNG type.");
      return createPendingDocument(ctx.user.id, { fileName: input.fileName, mimeType: input.mimeType, bytes, language: input.language });
    }),
    confirm: protectedProcedure.input(z.object({ documentId: z.number().int().positive(), edited: extracted })).mutation(({ ctx, input }) => confirmDocument(ctx.user.id, input.documentId, input.edited)),
    sourceFile: protectedProcedure.input(z.object({ documentId: z.number().int().positive() })).query(({ ctx, input }) => getAuthorizedDocumentDataUrl(ctx.user.id, input.documentId)),
    remove: protectedProcedure.input(z.object({ documentId: z.number().int().positive() })).mutation(({ ctx, input }) => removeHealthDocument(ctx.user.id, input.documentId)),
  }),
  copilot: router({
    ask: protectedProcedure.input(z.object({ question: z.string().trim().min(2).max(1600), conversationId: z.number().int().positive().optional(), language })).mutation(({ ctx, input }) => askCopilot(ctx.user.id, ctx.user.name ?? "HealthSahayak member", input)),
    conversation: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(({ ctx, input }) => getConversationHistory(ctx.user.id, input.id)),
  }),
  speech: router({
    transcribe: protectedProcedure.input(z.object({ base64: z.string().min(1).max(12_000_000), mimeType: z.string().min(1).max(120), language })).mutation(({ input }) => transcribeVoice(input)),
  }),
  admin: router({
    users: adminProcedure.query(async () => {
      const { listUsersForAdmin } = await import("./healthService");
      return listUsersForAdmin();
    }),
    setAccountType: adminProcedure.input(z.object({ userId: z.number().int().positive(), accountType: z.enum(["patient", "family_member", "caregiver", "doctor"]) })).mutation(async ({ input }) => {
      const { setAccountTypeForAdmin } = await import("./healthService");
      return setAccountTypeForAdmin(input.userId, input.accountType);
    }),
  }),
  care: router({
    grants: protectedProcedure.query(({ ctx }) => listCareGrants(ctx.user.id)),
    share: protectedProcedure.input(z.object({ email: z.string().email().max(320), relationship: z.enum(["family", "caregiver", "doctor"]), scopes: z.array(z.enum(["appointments", "medications", "reports", "tasks", "timeline"])).min(1).max(5) })).mutation(({ ctx, input }) => saveCareGrant(ctx.user.id, input.email, input.relationship, input.scopes)),
    revoke: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => revokeCareGrant(ctx.user.id, input.id)),
    sharedWithMe: protectedProcedure.query(({ ctx }) => getSharedRecords(ctx.user.id)),
  }),
});

export type AppRouter = typeof appRouter;
