import { randomInt, createHash } from "node:crypto";
import { and, desc, eq, gt, isNull, lt } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import type { Request, Response as ExpressResponse } from "express";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { emailLoginCodes, users } from "../drizzle/schema";
import { getDb } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { ENV } from "./_core/env";
import { sdk } from "./_core/sdk";
import { hashEmailCode, matchesEmailCode, normalizeAuthEmail, otpRetryAfterSeconds } from "./emailOtpPolicy";

const OTP_TTL_MS = 10 * 60 * 1000;
const OTP_RETENTION_MS = 60 * 60 * 1000;
const genericCodeError = "That code could not be verified. Check it or request a new one.";

function displayNameFromEmail(email: string): string {
  const local = email.split("@")[0].replace(/[._+-]+/g, " ").replace(/\s+/g, " ").trim();
  return (local || "HealthSahayak member").slice(0, 160);
}

function emailAuthUnavailable(): TRPCError {
  return new TRPCError({
    code: "PRECONDITION_FAILED",
    message: "Email sign-in is temporarily unavailable. Use the existing Manus sign-in option below.",
  });
}

async function sendResendEmail(apiKey: string, from: string, to: string, code: string, recordId: number): Promise<void> {
  let response: globalThis.Response;
  try {
    response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "Idempotency-Key": `healthsayhak-login-${recordId}`,
      },
      body: JSON.stringify({
        from,
        to: [to],
        subject: "Your HealthSahayak sign-in code",
        text: `Your HealthSahayak sign-in code is ${code}. It expires in 10 minutes and can be used once. If you did not request this code, you can ignore this email.`,
      }),
      signal: AbortSignal.timeout(12_000),
    });
  } catch {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Email delivery failed. Please try again or use Manus sign-in." });
  }
  if (!response.ok) {
    // Do not log an email, OTP, response body, API key or health information.
    console.warn(`[EmailAuth] Resend rejected a sign-in message (HTTP ${response.status})`);
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Email delivery failed. Please try again or use Manus sign-in." });
  }
}

export async function requestEmailCode(rawEmail: string): Promise<{ sent: boolean; retryAfterSeconds?: number }> {
  const email = normalizeAuthEmail(rawEmail);
  const apiKey = process.env.RESEND_API_KEY?.trim();
  const from = process.env.RESEND_FROM_EMAIL?.trim();
  if (!apiKey || !from || !ENV.cookieSecret) throw emailAuthUnavailable();

  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Email sign-in is temporarily unavailable." });

  const now = new Date();
  await db.delete(emailLoginCodes).where(lt(emailLoginCodes.createdAt, new Date(now.getTime() - OTP_RETENTION_MS)));
  const history = await db.select({ createdAt: emailLoginCodes.createdAt })
    .from(emailLoginCodes)
    .where(and(eq(emailLoginCodes.email, email), gt(emailLoginCodes.createdAt, new Date(now.getTime() - 60 * 60 * 1000))))
    .orderBy(desc(emailLoginCodes.createdAt))
    .limit(5);
  const retryAfterSeconds = otpRetryAfterSeconds(history.map(row => row.createdAt), now);
  if (retryAfterSeconds > 0) return { sent: false, retryAfterSeconds };

  const code = randomInt(0, 1_000_000).toString().padStart(6, "0");
  const codeHash = hashEmailCode(email, code, ENV.cookieSecret);
  const expiresAt = new Date(now.getTime() + OTP_TTL_MS);
  let inserted: { id: number } | undefined;
  await db.transaction(async tx => {
    await tx.update(emailLoginCodes)
      .set({ consumedAt: now })
      .where(and(eq(emailLoginCodes.email, email), isNull(emailLoginCodes.consumedAt)));
    const [row] = await tx.insert(emailLoginCodes)
      .values({ email, codeHash, expiresAt, attempts: 0 })
      .$returningId();
    inserted = row;
  });

  if (!inserted?.id) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Email sign-in is temporarily unavailable." });
  try {
    await sendResendEmail(apiKey, from, email, code, inserted.id);
  } catch (error) {
    await db.update(emailLoginCodes).set({ consumedAt: new Date() }).where(eq(emailLoginCodes.id, inserted.id));
    throw error;
  }
  // The same response is used whether this is a new or existing account.
  return { sent: true };
}

type VerifyResult =
  | { kind: "ok"; openId: string; name: string }
  | { kind: "invalid" }
  | { kind: "account-conflict" };

export async function verifyEmailCode(rawEmail: string, code: string, req: Request, res: ExpressResponse): Promise<{ success: true }> {
  const email = normalizeAuthEmail(rawEmail);
  const db = await getDb();
  if (!db || !ENV.cookieSecret) throw emailAuthUnavailable();
  const now = new Date();

  const result: VerifyResult = await db.transaction(async tx => {
    const [row] = await tx.select().from(emailLoginCodes)
      .where(and(eq(emailLoginCodes.email, email), isNull(emailLoginCodes.consumedAt)))
      .orderBy(desc(emailLoginCodes.createdAt))
      .limit(1)
      .for("update");

    if (!row || row.expiresAt.getTime() <= now.getTime() || row.attempts >= 5) {
      if (row) await tx.update(emailLoginCodes).set({ consumedAt: now }).where(eq(emailLoginCodes.id, row.id));
      return { kind: "invalid" };
    }
    if (!matchesEmailCode(email, code, ENV.cookieSecret, row.codeHash)) {
      const attempts = row.attempts + 1;
      await tx.update(emailLoginCodes)
        .set({ attempts, consumedAt: attempts >= 5 ? now : null })
        .where(eq(emailLoginCodes.id, row.id));
      return { kind: "invalid" };
    }

    await tx.update(emailLoginCodes).set({ consumedAt: now }).where(eq(emailLoginCodes.id, row.id));
    const matches = await tx.select().from(users).where(eq(users.email, email)).limit(2);
    if (matches.length > 1) return { kind: "account-conflict" };

    let user = matches[0];
    if (!user) {
      const openId = `email_${createHash("sha256").update(email).digest("hex").slice(0, 58)}`;
      const name = displayNameFromEmail(email);
      await tx.insert(users)
        .values({ openId, name, email, loginMethod: "email_otp", lastSignedIn: now })
        .onDuplicateKeyUpdate({ set: { email, name, loginMethod: "email_otp", lastSignedIn: now } });
      const [created] = await tx.select().from(users).where(eq(users.openId, openId)).limit(1);
      if (!created) return { kind: "account-conflict" };
      user = created;
    } else {
      await tx.update(users).set({ lastSignedIn: now }).where(eq(users.id, user.id));
    }
    return { kind: "ok", openId: user.openId, name: user.name || displayNameFromEmail(email) };
  });

  if (result.kind === "invalid") throw new TRPCError({ code: "BAD_REQUEST", message: genericCodeError });
  if (result.kind === "account-conflict") throw new TRPCError({ code: "CONFLICT", message: "Sign-in could not be completed. Use the existing Manus sign-in option." });

  const token = await sdk.createSessionToken(result.openId, { name: result.name, expiresInMs: ONE_YEAR_MS });
  res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
  return { success: true };
}
