import { describe, expect, it } from "vitest";
import { isValidDateOfBirth, onboardingInputSchema } from "./onboardingPolicy";

describe("first-use onboarding policy", () => {
  it("accepts minimal required identity fields when blood group, allergies and emergency details are unknown", () => {
    expect(onboardingInputSchema.safeParse({
      displayName: "Asha Rao",
      dateOfBirth: "1998-02-12",
      preferredLanguage: "en",
    }).success).toBe(true);
  });

  it("rejects missing names, malformed dates and unsupported languages", () => {
    expect(onboardingInputSchema.safeParse({ displayName: "  ", dateOfBirth: "1998-02-12", preferredLanguage: "en" }).success).toBe(false);
    expect(onboardingInputSchema.safeParse({ displayName: "Asha", dateOfBirth: "12/02/1998", preferredLanguage: "en" }).success).toBe(false);
    expect(onboardingInputSchema.safeParse({ displayName: "Asha", dateOfBirth: "1998-02-12", preferredLanguage: "xx" }).success).toBe(false);
  });

  it("accepts valid dates and rejects impossible, materially future, or over-125-year dates", () => {
    const now = new Date("2026-10-08T12:00:00.000Z");
    expect(isValidDateOfBirth("1998-02-12", now)).toBe(true);
    expect(isValidDateOfBirth("2026-02-12", now)).toBe(true);
    expect(isValidDateOfBirth("2026-10-09", now)).toBe(true); // Local date may be one calendar day ahead of UTC.
    expect(isValidDateOfBirth("2026-10-10", now)).toBe(false);
    expect(isValidDateOfBirth("2024-02-30", now)).toBe(false);
    expect(isValidDateOfBirth("1890-01-01", now)).toBe(false);
  });
});
