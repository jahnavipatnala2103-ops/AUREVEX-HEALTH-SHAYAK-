import { createHmac, timingSafeEqual } from "node:crypto";

export const normalizeAuthEmail = (value: string): string => value.trim().toLowerCase();

export function hashEmailCode(email: string, code: string, secret: string): string {
  const normalized = normalizeAuthEmail(email);
  return createHmac("sha256", secret).update(`${normalized}\0${code}`).digest("hex");
}

export function matchesEmailCode(email: string, code: string, secret: string, storedHash: string): boolean {
  const candidate = Buffer.from(hashEmailCode(email, code, secret), "hex");
  const expected = Buffer.from(storedHash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

/** Returns seconds until another email is allowed, or 0 if the address is clear. */
export function otpRetryAfterSeconds(createdAt: Date[], now = new Date()): number {
  const recent = createdAt
    .map(date => date.getTime())
    .filter(time => time <= now.getTime() && now.getTime() - time < 60 * 60 * 1000)
    .sort((a, b) => a - b);

  const lastMinute = recent.filter(time => now.getTime() - time < 60 * 1000);
  const cooldownSeconds = lastMinute.length
    ? Math.max(1, Math.ceil(60 - (now.getTime() - lastMinute[lastMinute.length - 1]) / 1000))
    : 0;
  const hourlyLimitSeconds = recent.length >= 5
    ? Math.max(1, Math.ceil(60 * 60 - (now.getTime() - recent[0]) / 1000))
    : 0;
  return Math.max(cooldownSeconds, hourlyLimitSeconds);
}
