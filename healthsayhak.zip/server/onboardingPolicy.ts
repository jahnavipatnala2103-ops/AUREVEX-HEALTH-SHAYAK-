import { z } from "zod";

export const onboardingInputSchema = z.object({
  displayName: z.string().trim().min(1, "Enter your name.").max(180),
  dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Enter a valid date of birth."),
  preferredLanguage: z.enum(["en", "te", "hi"]),
  bloodGroup: z.string().trim().max(16).optional(),
  allergies: z.array(z.string().trim().min(1).max(120)).max(30).optional(),
  emergencyName: z.string().max(160).optional(),
  emergencyPhone: z.string().max(48).optional(),
  emergencyInformation: z.string().max(1000).optional(),
});

export type OnboardingInput = z.infer<typeof onboardingInputSchema>;

/** Accept a user's local calendar date while rejecting impossible or materially future dates. */
export function isValidDateOfBirth(value: string, now = new Date()): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const birth = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(birth.getTime()) || birth.toISOString().slice(0, 10) !== value) return false;

  // A one-day margin accommodates users east of UTC whose local calendar has already advanced.
  const reference = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  const referenceDate = reference.toISOString().slice(0, 10);
  if (value > referenceDate) return false;
  let age = reference.getUTCFullYear() - birth.getUTCFullYear();
  if (reference.getUTCMonth() < birth.getUTCMonth() || (reference.getUTCMonth() === birth.getUTCMonth() && reference.getUTCDate() < birth.getUTCDate())) age -= 1;
  return age >= 0 && age <= 125;
}
