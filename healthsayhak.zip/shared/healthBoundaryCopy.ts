import type { HealthLanguage } from "./health";

export type HealthBoundaryKey =
  | "healthOnlyAnswer"
  | "healthOnlyLabel"
  | "notHealthDocument"
  | "checkHealthDocument"
  | "healthCheckUnavailable"
  | "pdfPreviewFailed"
  | "documentDisclosure"
  | "deleteButton"
  | "deleteConfirm"
  | "deleteDraftConfirm"
  | "deleteDraftSuccess"
  | "deleteSuccess"
  | "deleteError"
  | "deleting";

const copy: Record<HealthLanguage, Record<HealthBoundaryKey, string>> = {
  en: {
    healthOnlyAnswer: "I can help with health-related questions only. Try asking about a report, medication, appointment or symptom.",
    healthOnlyLabel: "HEALTH-ONLY RESPONSE",
    notHealthDocument: "This file doesn't clearly appear to be a health document. It was rejected before being saved to project storage or your health records. Try a lab report, prescription, doctor's note, discharge summary, insurance record or other healthcare document.",
    checkHealthDocument: "Checking the file's contents for health information before saving or extracting any details.",
    healthCheckUnavailable: "We couldn't complete the health-document check, so the file was not saved. Please try again.",
    pdfPreviewFailed: "We couldn't safely read this PDF, so it was not saved. Try another PDF or upload a clear photo of a page.",
    documentDisclosure: "After you consent, the file is sent to the configured AI service for a health-document check before it is saved. Unrelated or unreadable files are rejected before project storage. Accepted files are stored after the check. Deleting a saved file removes it from HealthSahayak, but this Preview's storage service cannot physically erase the uploaded bytes. Use synthetic or test documents only. This is not medical care.",
    deleteButton: "Delete",
    deleteConfirm: "Remove this document and its linked health record, Journey entries and cited Copilot turns from HealthSahayak? It will disappear from your Vault and future Copilot context. The Preview storage service cannot physically erase the uploaded file; its bytes remain in managed project storage. Other previously saved chat text may remain.",
    deleteDraftConfirm: "Delete this unconfirmed upload from HealthSahayak? It will not be added to your Vault, Profile, Journey or future Copilot context. The Preview storage service cannot physically erase the uploaded bytes; they remain in managed project storage.",
    deleteDraftSuccess: "The unconfirmed upload was removed from HealthSahayak. Its original bytes remain in managed project storage.",
    deleteSuccess: "Removed from your Health Vault and future Copilot context. The uploaded source bytes remain in project storage.",
    deleteError: "This document could not be removed. Please refresh and try again.",
    deleting: "Deleting…",
  },
  te: {
    healthOnlyAnswer: "నేను ఆరోగ్యానికి సంబంధించిన ప్రశ్నలకు మాత్రమే సహాయం చేయగలను. నివేదిక, మందు, అపాయింట్‌మెంట్ లేదా లక్షణం గురించి అడగండి.",
    healthOnlyLabel: "ఆరోగ్య ప్రశ్నకు మాత్రమే స్పందన",
    notHealthDocument: "ఈ ఫైల్ స్పష్టంగా ఆరోగ్య పత్రంలా కనిపించడం లేదు. ప్రాజెక్ట్ స్టోరేజ్ లేదా మీ ఆరోగ్య రికార్డుల్లో సేవ్ చేయకముందే తిరస్కరించబడింది. ల్యాబ్ నివేదిక, ప్రిస్క్రిప్షన్, వైద్యుని నోట్, డిశ్చార్జ్ సమ్మరీ, బీమా రికార్డు లేదా ఇతర ఆరోగ్య పత్రాన్ని ప్రయత్నించండి.",
    checkHealthDocument: "సేవ్ చేయడం లేదా వివరాలు వెలికితీయడం ముందు, ఈ ఫైల్‌లో ఆరోగ్య సమాచారం ఉందో లేదో పరిశీలిస్తున్నాం.",
    healthCheckUnavailable: "ఆరోగ్య పత్రం తనిఖీ పూర్తికాలేదు; కాబట్టి ఫైల్ సేవ్ చేయలేదు. దయచేసి మళ్లీ ప్రయత్నించండి.",
    pdfPreviewFailed: "ఈ PDF‌ను సురక్షితంగా చదవలేకపోయాం; అందువల్ల సేవ్ చేయలేదు. మరో PDF లేదా స్పష్టమైన పేజీ ఫోటోను అప్‌లోడ్ చేయండి.",
    documentDisclosure: "మీ అనుమతి తర్వాత, సేవ్ చేసే ముందు ఆరోగ్య పత్రం తనిఖీ కోసం ఫైల్ కాన్ఫిగర్ చేసిన AI సేవకు పంపబడుతుంది. సంబంధంలేని లేదా చదవలేని ఫైళ్లు ప్రాజెక్ట్ స్టోరేజ్‌కు ముందే తిరస్కరించబడతాయి. తనిఖీ తర్వాత అంగీకరించిన ఫైళ్లు సేవ్ అవుతాయి. సేవ్ చేసిన ఫైల్‌ను తొలగించినా, ఈ Preview స్టోరేజ్ సేవ అప్‌లోడ్ డేటాను భౌతికంగా చెరపలేదు. కృత్రిమ లేదా పరీక్షా పత్రాలనే ఉపయోగించండి. ఇది వైద్య సేవ కాదు.",
    deleteButton: "తొలగించండి",
    deleteConfirm: "ఈ పత్రం, దానికి సంబంధించిన ఆరోగ్య రికార్డు, Journey ఎంట్రీలు మరియు దానిని ఉటంకించిన Copilot చాట్‌లను HealthSahayak నుంచి తొలగించాలా? ఇది మీ Vault మరియు భవిష్యత్తు Copilot సందర్భంలో కనిపించదు. Preview స్టోరేజ్ ఫైల్ డేటాను భౌతికంగా చెరపలేదు; అది ప్రాజెక్ట్ స్టోరేజ్‌లో ఉంటుంది. ఇతర పాత చాట్ పాఠ్యం మిగిలి ఉండవచ్చు.",
    deleteDraftConfirm: "ధృవీకరించని ఈ అప్‌లోడ్‌ను HealthSahayak నుంచి తొలగించాలా? ఇది మీ Vault, Profile, Journey లేదా భవిష్యత్తు Copilot సందర్భంలో చేరదు. Preview స్టోరేజ్ అప్‌లోడ్ డేటాను భౌతికంగా చెరపలేదు; అది ప్రాజెక్ట్ స్టోరేజ్‌లో ఉంటుంది.",
    deleteDraftSuccess: "ధృవీకరించని అప్‌లోడ్ HealthSahayak నుంచి తొలగించబడింది. దాని మూల డేటా ప్రాజెక్ట్ స్టోరేజ్‌లోనే ఉంటుంది.",
    deleteSuccess: "మీ ఆరోగ్య Vault మరియు భవిష్యత్తు Copilot సందర్భం నుంచి తొలగించబడింది. మూల ఫైల్ డేటా ప్రాజెక్ట్ స్టోరేజ్‌లోనే ఉంటుంది.",
    deleteError: "ఈ పత్రాన్ని తొలగించలేకపోయాం. రిఫ్రెష్ చేసి మళ్లీ ప్రయత్నించండి.",
    deleting: "తొలగిస్తోంది…",
  },
  hi: {
    healthOnlyAnswer: "मैं केवल स्वास्थ्य-संबंधी सवालों में मदद कर सकता हूँ। रिपोर्ट, दवा, अपॉइंटमेंट या लक्षण के बारे में पूछें।",
    healthOnlyLabel: "केवल स्वास्थ्य-संबंधी उत्तर",
    notHealthDocument: "यह फ़ाइल स्पष्ट रूप से स्वास्थ्य दस्तावेज़ नहीं लगती। इसे project storage या आपके स्वास्थ्य रिकॉर्ड में सहेजने से पहले अस्वीकार कर दिया गया। कृपया लैब रिपोर्ट, प्रिस्क्रिप्शन, डॉक्टर का नोट, डिस्चार्ज सारांश, बीमा रिकॉर्ड या कोई अन्य स्वास्थ्य दस्तावेज़ चुनें।",
    checkHealthDocument: "सहेजने या विवरण निकालने से पहले फ़ाइल में स्वास्थ्य जानकारी की जाँच की जा रही है।",
    healthCheckUnavailable: "स्वास्थ्य दस्तावेज़ की जाँच पूरी नहीं हो सकी, इसलिए फ़ाइल सहेजी नहीं गई। कृपया फिर कोशिश करें।",
    pdfPreviewFailed: "इस PDF को सुरक्षित रूप से पढ़ नहीं सके, इसलिए इसे सहेजा नहीं गया। कोई दूसरा PDF या पेज की साफ़ तस्वीर अपलोड करें।",
    documentDisclosure: "आपकी सहमति के बाद, सहेजने से पहले स्वास्थ्य दस्तावेज़ की जाँच के लिए फ़ाइल configured AI सेवा को भेजी जाती है। असंबंधित या अपठनीय फ़ाइलें project storage में सहेजने से पहले अस्वीकार कर दी जाती हैं। जाँच के बाद स्वीकार की गई फ़ाइलें सहेजी जाती हैं। सहेजी गई फ़ाइल हटाने पर भी यह Preview storage सेवा उसके bytes को स्थायी रूप से नहीं मिटा सकती। केवल कृत्रिम या परीक्षण दस्तावेज़ इस्तेमाल करें। यह चिकित्सा सेवा नहीं है।",
    deleteButton: "हटाएँ",
    deleteConfirm: "क्या यह दस्तावेज़, इससे जुड़े स्वास्थ्य रिकॉर्ड, Journey प्रविष्टियाँ और इसे उद्धृत करने वाले Copilot turns HealthSahayak से हटाएँ? यह आपके Vault और भविष्य के Copilot संदर्भ में नहीं दिखेगा। Preview storage सेवा अपलोड की गई फ़ाइल को भौतिक रूप से नहीं मिटा सकती; उसके bytes project storage में रहेंगे। अन्य पुराने chat text बने रह सकते हैं।",
    deleteDraftConfirm: "क्या इस अपुष्ट अपलोड को HealthSahayak से हटाएँ? इसे आपके Vault, Profile, Journey या भविष्य के Copilot संदर्भ में नहीं जोड़ा जाएगा। Preview storage सेवा अपलोड bytes को भौतिक रूप से नहीं मिटा सकती; वे project storage में रहेंगे।",
    deleteDraftSuccess: "अपुष्ट अपलोड HealthSahayak से हटा दिया गया। उसके मूल bytes project storage में रहेंगे।",
    deleteSuccess: "आपके Health Vault और भविष्य के Copilot संदर्भ से हटा दिया गया। मूल फ़ाइल के bytes project storage में रहेंगे।",
    deleteError: "यह दस्तावेज़ हटाया नहीं जा सका। कृपया refresh करके फिर कोशिश करें।",
    deleting: "हटाया जा रहा है…",
  },
};

export function healthBoundaryText(language: HealthLanguage, key: HealthBoundaryKey): string {
  return copy[language]?.[key] ?? copy.en[key];
}
