export type HealthLanguage = "en" | "te" | "hi";
export type DocumentKind =
  | "lab_report"
  | "prescription"
  | "doctor_note"
  | "discharge_summary"
  | "insurance"
  | "medical_record"
  | "wellness"
  | "other";
export type DocumentStatus = "review" | "confirmed" | "failed";
export type HealthRecordKind =
  | "observation"
  | "medication"
  | "encounter"
  | "condition"
  | "appointment"
  | "insurance"
  | "discharge"
  | "wellness";
export type JourneyKind =
  | "report"
  | "consultation"
  | "medication"
  | "appointment"
  | "follow_up"
  | "insurance"
  | "discharge"
  | "wellness";

export type ExtractedObservation = {
  test: string;
  value: string;
  unit: string;
  referenceRange: string;
  outsideRange: boolean | null;
  sourceText: string;
};

export type ExtractedMedication = {
  name: string;
  dosage: string;
  frequency: string;
  instructions: string;
  duration: string;
  prescribedBy: string;
  sourceText: string;
};

export type ExtractedHealthDocument = {
  kind: DocumentKind;
  title: string;
  documentDate: string;
  provider: string;
  observations: ExtractedObservation[];
  medications: ExtractedMedication[];
  symptoms: string[];
  assessments: string[];
  recommendations: string[];
  diagnoses: string[];
  procedures: string[];
  admissionDate: string;
  dischargeDate: string;
  followUpInstructions: string[];
  insuranceProvider: string;
  policyInformation: string;
  importantFindings: string[];
  whatThisMeans: string;
  sourceNote: string;
  confidenceNote: string;
};

export type ProfileSummary = {
  id: number;
  name: string;
  onboardingCompleted: boolean;
  dateOfBirth: string | null;
  gender: string | null;
  bloodGroup: string | null;
  preferredLanguage: HealthLanguage;
  allergies: string[];
  conditions: string[];
  importantInformation: string;
  emergencyName: string;
  emergencyPhone: string;
  emergencyInformation: string;
  insuranceProvider: string;
  policyInformation: string;
  policyDates: string;
  mockAbhaId: string;
  accountType: string;
};

export type HealthDocumentSummary = {
  id: number;
  fileName: string;
  mimeType: string;
  kind: DocumentKind;
  status: DocumentStatus;
  documentDate: string | null;
  uploadedAt: string;
  summary: ExtractedHealthDocument | null;
  isDemo: boolean;
  recordId: number | null;
};

export type HealthRecordSummary = {
  id: number;
  kind: HealthRecordKind;
  title: string;
  recordDate: string | null;
  data: Record<string, unknown>;
  documentId: number | null;
  isDemo: boolean;
};

export type JourneyEventSummary = {
  id: number;
  kind: JourneyKind;
  title: string;
  detail: string;
  eventDate: string;
  recordId: number | null;
  documentId: number | null;
  isDemo: boolean;
};

export type CareTaskSummary = {
  id: number;
  title: string;
  dueDate: string | null;
  completed: boolean;
  isDemo: boolean;
};

export type ConversationSummary = {
  id: number;
  title: string;
  updatedAt: string;
};

export type HealthOverview = {
  profile: ProfileSummary;
  documents: HealthDocumentSummary[];
  records: HealthRecordSummary[];
  events: JourneyEventSummary[];
  tasks: CareTaskSummary[];
  conversations: ConversationSummary[];
};

export type CopilotSource = { id: number; title: string; date: string; kind: string; documentId?: number | null };
export type CopilotReply = {
  whatWeKnow: string[];
  generalInformation: string;
  uncertain: string;
  nextStep: string;
  sources: CopilotSource[];
};

export type AccessScope = "appointments" | "medications" | "reports" | "tasks" | "timeline";
export type CareGrantSummary = {
  id: number;
  email: string;
  name: string;
  relationship: "family" | "caregiver" | "doctor";
  scopes: AccessScope[];
  status: "active" | "revoked";
};
