CREATE TABLE `email_login_codes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`code_hash` varchar(64) NOT NULL,
	`expires_at` timestamp NOT NULL,
	`attempts` int NOT NULL DEFAULT 0,
	`consumed_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `email_login_codes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `email_login_codes_email_created_idx` ON `email_login_codes` (`email`,`created_at`);