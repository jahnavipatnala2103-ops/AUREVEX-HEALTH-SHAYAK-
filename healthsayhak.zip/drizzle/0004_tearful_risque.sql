ALTER TABLE `health_profiles` ADD `onboarding_completed` boolean DEFAULT false NOT NULL;

--> statement-breakpoint
ALTER TABLE `health_records` MODIFY COLUMN `kind` enum('observation','medication','encounter','condition','appointment','insurance','discharge','wellness') NOT NULL;
