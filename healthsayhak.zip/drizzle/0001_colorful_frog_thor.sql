CREATE TABLE `care_grants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`owner_id` int NOT NULL,
	`grantee_user_id` int,
	`grantee_email` varchar(320) NOT NULL,
	`relationship` enum('family','caregiver','doctor') NOT NULL,
	`scopes` json NOT NULL,
	`status` enum('active','revoked') NOT NULL DEFAULT 'active',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`revoked_at` timestamp,
	CONSTRAINT `care_grants_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `care_tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`owner_id` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`due_date` timestamp,
	`completed` boolean NOT NULL DEFAULT false,
	`is_demo` boolean NOT NULL DEFAULT false,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `care_tasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `copilot_conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`owner_id` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`language` enum('en','te','hi') NOT NULL DEFAULT 'en',
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `copilot_conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `copilot_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversation_id` int NOT NULL,
	`owner_id` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`content` text NOT NULL,
	`structured_reply` json,
	`sources` json,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `copilot_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `health_documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`owner_id` int NOT NULL,
	`file_name` varchar(255) NOT NULL,
	`mime_type` varchar(100) NOT NULL,
	`storage_key` varchar(512) NOT NULL,
	`kind` enum('lab_report','prescription','doctor_note','discharge_summary','insurance','medical_record','wellness','other') NOT NULL DEFAULT 'other',
	`status` enum('review','confirmed','failed') NOT NULL DEFAULT 'review',
	`extracted_data` json,
	`is_demo` boolean NOT NULL DEFAULT false,
	`record_id` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `health_documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `health_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`date_of_birth` varchar(10),
	`gender` varchar(80),
	`blood_group` varchar(16),
	`preferred_language` enum('en','te','hi') NOT NULL DEFAULT 'en',
	`allergies` json NOT NULL,
	`conditions` json NOT NULL,
	`important_information` text,
	`emergency_name` varchar(160),
	`emergency_phone` varchar(48),
	`emergency_information` text,
	`insurance_provider` varchar(180),
	`policy_information` text,
	`policy_dates` varchar(160),
	`mock_abha_id` varchar(80) NOT NULL,
	`account_type` enum('patient','family_member','caregiver','doctor') NOT NULL DEFAULT 'patient',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `health_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `health_profiles_user_id_uq` UNIQUE(`user_id`)
);
--> statement-breakpoint
CREATE TABLE `health_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`owner_id` int NOT NULL,
	`document_id` int,
	`kind` enum('observation','medication','encounter','condition','appointment','insurance','discharge','wellness') NOT NULL,
	`title` varchar(255) NOT NULL,
	`record_date` timestamp,
	`data` json NOT NULL,
	`is_demo` boolean NOT NULL DEFAULT false,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `health_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `journey_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`owner_id` int NOT NULL,
	`record_id` int,
	`kind` enum('report','consultation','medication','appointment','follow_up','discharge','wellness') NOT NULL,
	`title` varchar(255) NOT NULL,
	`detail` text,
	`event_date` timestamp NOT NULL,
	`is_demo` boolean NOT NULL DEFAULT false,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `journey_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `care_grants` ADD CONSTRAINT `care_grants_owner_id_users_id_fk` FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `care_grants` ADD CONSTRAINT `care_grants_grantee_user_id_users_id_fk` FOREIGN KEY (`grantee_user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `care_tasks` ADD CONSTRAINT `care_tasks_owner_id_users_id_fk` FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `copilot_conversations` ADD CONSTRAINT `copilot_conversations_owner_id_users_id_fk` FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `copilot_messages` ADD CONSTRAINT `copilot_messages_conversation_id_copilot_conversations_id_fk` FOREIGN KEY (`conversation_id`) REFERENCES `copilot_conversations`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `copilot_messages` ADD CONSTRAINT `copilot_messages_owner_id_users_id_fk` FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `health_documents` ADD CONSTRAINT `health_documents_owner_id_users_id_fk` FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `health_profiles` ADD CONSTRAINT `health_profiles_user_id_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `health_records` ADD CONSTRAINT `health_records_owner_id_users_id_fk` FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `health_records` ADD CONSTRAINT `health_records_document_id_health_documents_id_fk` FOREIGN KEY (`document_id`) REFERENCES `health_documents`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `journey_events` ADD CONSTRAINT `journey_events_owner_id_users_id_fk` FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `journey_events` ADD CONSTRAINT `journey_events_record_id_health_records_id_fk` FOREIGN KEY (`record_id`) REFERENCES `health_records`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `care_grants_owner_status_idx` ON `care_grants` (`owner_id`,`status`);--> statement-breakpoint
CREATE INDEX `care_tasks_owner_created_idx` ON `care_tasks` (`owner_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `copilot_conversations_owner_updated_idx` ON `copilot_conversations` (`owner_id`,`updated_at`);--> statement-breakpoint
CREATE INDEX `copilot_messages_conversation_idx` ON `copilot_messages` (`conversation_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `health_documents_owner_created_idx` ON `health_documents` (`owner_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `health_records_owner_date_idx` ON `health_records` (`owner_id`,`record_date`);--> statement-breakpoint
CREATE INDEX `journey_events_owner_date_idx` ON `journey_events` (`owner_id`,`event_date`);