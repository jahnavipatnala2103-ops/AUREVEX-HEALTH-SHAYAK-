import {
  boolean,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";
import type {
  AccessScope,
  ExtractedHealthDocument,
  HealthLanguage,
} from "../shared/health";

/** Core identity table used by the starter's Manus OAuth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const healthProfiles = mysqlTable(
  "health_profiles",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    displayName: varchar("display_name", { length: 180 }),
    onboardingCompleted: boolean("onboarding_completed").default(false).notNull(),
    dateOfBirth: varchar("date_of_birth", { length: 10 }),
    gender: varchar("gender", { length: 80 }),
    bloodGroup: varchar("blood_group", { length: 16 }),
    preferredLanguage: mysqlEnum("preferred_language", ["en", "te", "hi"]).default("en").notNull(),
    allergies: json("allergies").$type<string[]>().notNull(),
    conditions: json("conditions").$type<string[]>().notNull(),
    importantInformation: text("important_information"),
    emergencyName: varchar("emergency_name", { length: 160 }),
    emergencyPhone: varchar("emergency_phone", { length: 48 }),
    emergencyInformation: text("emergency_information"),
    insuranceProvider: varchar("insurance_provider", { length: 180 }),
    policyInformation: text("policy_information"),
    policyDates: varchar("policy_dates", { length: 160 }),
    mockAbhaId: varchar("mock_abha_id", { length: 80 }).notNull(),
    accountType: mysqlEnum("account_type", ["patient", "family_member", "caregiver", "doctor"]).default("patient").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("health_profiles_user_id_uq").on(table.userId)],
);

export const healthDocuments = mysqlTable(
  "health_documents",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    fileName: varchar("file_name", { length: 255 }).notNull(),
    mimeType: varchar("mime_type", { length: 100 }).notNull(),
    storageKey: varchar("storage_key", { length: 512 }).notNull(),
    kind: mysqlEnum("kind", ["lab_report", "prescription", "doctor_note", "discharge_summary", "insurance", "medical_record", "wellness", "other"]).default("other").notNull(),
    status: mysqlEnum("status", ["review", "confirmed", "failed"]).default("review").notNull(),
    extractedData: json("extracted_data").$type<ExtractedHealthDocument | null>(),
    isDemo: boolean("is_demo").default(false).notNull(),
    recordId: int("record_id"),
    deletedAt: timestamp("deleted_at"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  table => [index("health_documents_owner_created_idx").on(table.ownerId, table.createdAt)],
);

export const healthRecords = mysqlTable(
  "health_records",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    documentId: int("document_id").references(() => healthDocuments.id, { onDelete: "set null" }),
    kind: mysqlEnum("kind", ["observation", "medication", "encounter", "condition", "appointment", "insurance", "discharge", "wellness"]).notNull(),
    title: varchar("title", { length: 255 }).notNull(),
    recordDate: timestamp("record_date"),
    data: json("data").$type<Record<string, unknown>>().notNull(),
    isDemo: boolean("is_demo").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  table => [index("health_records_owner_date_idx").on(table.ownerId, table.recordDate)],
);

export const journeyEvents = mysqlTable(
  "journey_events",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    recordId: int("record_id").references(() => healthRecords.id, { onDelete: "set null" }),
    kind: mysqlEnum("kind", ["report", "consultation", "medication", "appointment", "follow_up", "insurance", "discharge", "wellness"]).notNull(),
    title: varchar("title", { length: 255 }).notNull(),
    detail: text("detail"),
    eventDate: timestamp("event_date").notNull(),
    isDemo: boolean("is_demo").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  table => [index("journey_events_owner_date_idx").on(table.ownerId, table.eventDate)],
);

export const careTasks = mysqlTable(
  "care_tasks",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 255 }).notNull(),
    dueDate: timestamp("due_date"),
    completed: boolean("completed").default(false).notNull(),
    isDemo: boolean("is_demo").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  table => [index("care_tasks_owner_created_idx").on(table.ownerId, table.createdAt)],
);

export const copilotConversations = mysqlTable(
  "copilot_conversations",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 180 }).notNull(),
    language: mysqlEnum("language", ["en", "te", "hi"]).default("en").notNull(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  table => [index("copilot_conversations_owner_updated_idx").on(table.ownerId, table.updatedAt)],
);

export const copilotMessages = mysqlTable(
  "copilot_messages",
  {
    id: int("id").autoincrement().primaryKey(),
    conversationId: int("conversation_id").notNull().references(() => copilotConversations.id, { onDelete: "cascade" }),
    ownerId: int("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    role: mysqlEnum("role", ["user", "assistant"]).notNull(),
    content: text("content").notNull(),
    structuredReply: json("structured_reply").$type<Record<string, unknown> | null>(),
    sources: json("sources").$type<Array<Record<string, unknown>>>(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  table => [index("copilot_messages_conversation_idx").on(table.conversationId, table.createdAt)],
);

export const careGrants = mysqlTable(
  "care_grants",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("owner_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    granteeUserId: int("grantee_user_id").references(() => users.id, { onDelete: "cascade" }),
    granteeEmail: varchar("grantee_email", { length: 320 }).notNull(),
    relationship: mysqlEnum("relationship", ["family", "caregiver", "doctor"]).notNull(),
    scopes: json("scopes").$type<AccessScope[]>().notNull(),
    status: mysqlEnum("status", ["active", "revoked"]).default("active").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    revokedAt: timestamp("revoked_at"),
  },
  table => [index("care_grants_owner_status_idx").on(table.ownerId, table.status)],
);


/** Single-use email sign-in challenges. The six-digit code is never stored, only a keyed hash. */
export const emailLoginCodes = mysqlTable(
  "email_login_codes",
  {
    id: int("id").autoincrement().primaryKey(),
    email: varchar("email", { length: 320 }).notNull(),
    codeHash: varchar("code_hash", { length: 64 }).notNull(),
    expiresAt: timestamp("expires_at").notNull(),
    attempts: int("attempts").default(0).notNull(),
    consumedAt: timestamp("consumed_at"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  table => [index("email_login_codes_email_created_idx").on(table.email, table.createdAt)],
);
