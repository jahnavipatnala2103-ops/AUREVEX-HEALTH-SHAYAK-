import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import type { User } from "../../../drizzle/schema";
import { toast } from "sonner";
import { BrandMark } from "@/components/BrandMark";
import { Bell, ChevronDown, FileHeart, House, LogOut, MessageCircleHeart, ShieldCheck, UserRound, Waypoints } from "lucide-react";
import type { HealthLanguage } from "@shared/health";
import { t } from "@/lib/i18n";
import { w } from "@/lib/workflowCopy";

const navigation = [
  { path: "/", key: "home" as const, icon: House },
  { path: "/copilot", key: "copilot" as const, icon: MessageCircleHeart },
  { path: "/vault", key: "vault" as const, icon: FileHeart },
  { path: "/journey", key: "journey" as const, icon: Waypoints },
  { path: "/profile", key: "profile" as const, icon: UserRound },
];
const languageNames: Record<HealthLanguage, string> = { en: "EN", te: "తెలుగు", hi: "हिन्दी" };

export function AppShell({ children, user, onSignOut }: { children: React.ReactNode; user: User; onSignOut: () => Promise<void> }) {
  const [location, navigate] = useLocation();
  const [updatesOpen, setUpdatesOpen] = useState(false);
  const utils = trpc.useUtils();
  const overview = trpc.health.overview.useQuery(undefined, { retry: false });
  const updateProfile = trpc.health.updateProfile.useMutation({
    onSuccess: () => { void utils.health.overview.invalidate(); toast.success("Language preference updated."); },
    onError: () => toast.error("The language preference could not be saved."),
  });
  const language = overview.data?.profile.preferredLanguage ?? "en";
  const active = useMemo(() => navigation.find(item => item.path === location) ?? navigation[0], [location]);
  const activeLabel = t(language, active.key);
  const now = new Date();
  const updates = [
    ...(overview.data?.tasks.filter(task => !task.completed).slice(0, 3).map(task => ({ title: task.title, detail: task.dueDate ? `Due ${new Date(task.dueDate).toLocaleDateString()}` : t(language, "nextStep"), path: "/profile" })) ?? []),
    ...(overview.data?.records.filter(record => record.kind === "appointment" && record.recordDate && new Date(record.recordDate) >= now).slice(0, 1).map(record => ({ title: String(record.data.doctor ?? t(language, "appointments")), detail: new Date(record.recordDate!).toLocaleDateString(), path: "/profile" })) ?? []),
    ...(overview.data?.documents.filter(document => document.status === "review").slice(0, 2).map(document => ({ title: w(language, "pendingReview"), detail: document.summary?.title ?? document.fileName, path: `/vault?document=${document.id}` })) ?? []),
    ...(overview.data?.documents.filter(document => document.status === "confirmed" && !document.isDemo).slice(0, 1).map(document => ({ title: w(language, "recentRecord"), detail: document.summary?.title ?? document.fileName, path: `/vault?document=${document.id}` })) ?? []),
  ].slice(0, 5);

  const cycleLanguage = () => {
    const next: Record<HealthLanguage, HealthLanguage> = { en: "te", te: "hi", hi: "en" };
    updateProfile.mutate({ preferredLanguage: next[language] });
  };
  const handleSignOut = async () => {
    try { await onSignOut(); }
    catch { toast.error("Could not sign out. Please try again."); }
  };

  return (
    <div className="app-frame">
      <aside className="desktop-sidebar" aria-label="Main navigation">
        <button className="brand-lockup" onClick={() => navigate("/")} aria-label="HealthSahayak home">
          <BrandMark /><span><strong>HealthSahayak</strong><small>YOUR HEALTH, IN CONTEXT</small></span>
        </button>
        <div className="sidebar-caption">YOUR SPACE</div>
        <nav className="primary-nav">
          {navigation.map(item => {
            const Icon = item.icon; const selected = active.path === item.path; const label = t(language, item.key);
            return <button key={item.path} className={`nav-item ${selected ? "selected" : ""}`} aria-current={selected ? "page" : undefined} onClick={() => navigate(item.path)}><Icon size={19} strokeWidth={selected ? 2.2 : 1.8} /><span>{label}</span>{selected && <span className="nav-indicator" />}</button>;
          })}
        </nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-trust"><span><ShieldCheck size={16} /></span><div><strong>Your records, in context</strong><small>Use synthetic demo files</small></div></div>
        <button className="account-switch" onClick={() => navigate("/profile")}>
          <span className="avatar-initials">{(user.name ?? "H").trim().slice(0, 1).toUpperCase()}</span>
          <span className="account-name"><strong>{user.name || "HealthSahayak member"}</strong><small>{user.email || "Personal health profile"}</small></span>
          <ChevronDown size={16} />
        </button>
      </aside>

      <div className="app-main">
        <header className="topbar">
          <div className="mobile-brand"><BrandMark /><span>HealthSahayak</span></div>
          <div className="topbar-crumb"><span>My health</span><span className="crumb-divider">/</span><strong>{activeLabel}</strong></div>
          <div className="topbar-actions">
            <button className="language-button" onClick={cycleLanguage} aria-label="Change language" title="Change language">{languageNames[language]}<ChevronDown size={13} /></button>
            <button className="icon-button" aria-label={w(language, "notifications")} aria-expanded={updatesOpen} onClick={() => setUpdatesOpen(value => !value)}><Bell size={18} />{updates.length > 0 && <span className="notification-dot" />}</button>{updatesOpen && <section className="updates-menu card" aria-label={w(language, "healthUpdates")}><div className="updates-menu-heading"><strong>{w(language, "healthUpdates")}</strong><button className="icon-button" aria-label={w(language, "dismiss")} onClick={() => setUpdatesOpen(false)}><span aria-hidden="true">×</span></button></div>{updates.length ? <div className="updates-list">{updates.map((item, index) => <button className="update-item" key={`${item.path}-${index}`} onClick={() => { navigate(item.path); setUpdatesOpen(false); }}><span className="update-dot" /><span><strong>{item.title}</strong><small>{item.detail}</small></span><ChevronDown size={13} /></button>)}</div> : <p className="updates-empty">{w(language, "caughtUp")}</p>}</section>}
            <button className="topbar-user" onClick={() => navigate("/profile")} aria-label="Open profile"><span className="avatar-initials small">{(user.name ?? "H").trim().slice(0, 1).toUpperCase()}</span></button>
            <button className="signout-button" onClick={handleSignOut} title="Sign out" aria-label="Sign out"><LogOut size={17} /></button>
          </div>
        </header>
        <main className="page-content">{children}</main>
        <footer className="app-footer"><span>HealthSahayak · Personal health journey</span><span>Not a substitute for professional care</span></footer>
      </div>
      <nav className="mobile-nav" aria-label="Main navigation">
        {navigation.map(item => { const Icon = item.icon; const selected = active.path === item.path; return <button key={item.path} className={selected ? "selected" : ""} aria-label={t(language, item.key)} aria-current={selected ? "page" : undefined} onClick={() => navigate(item.path)}><Icon size={20} /><span>{t(language, item.key)}</span></button>; })}
      </nav>
    </div>
  );
}
