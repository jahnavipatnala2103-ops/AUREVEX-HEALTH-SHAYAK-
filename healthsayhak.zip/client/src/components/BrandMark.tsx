import { cn } from "@/lib/utils";

export function BrandMark({ className }: { className?: string }) {
  return (
    <svg className={cn("brand-mark", className)} viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <rect x="1" y="1" width="38" height="38" rx="13" fill="currentColor" />
      <path d="M12 11.5V28.5M28 11.5V28.5M12 20H28" stroke="#F4FAF8" strokeWidth="3.2" strokeLinecap="round" />
      <circle cx="12" cy="20" r="2.2" fill="#C9E9DF" />
      <circle cx="28" cy="20" r="2.2" fill="#C9E9DF" />
    </svg>
  );
}
