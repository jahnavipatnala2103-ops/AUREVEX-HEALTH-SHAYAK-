import { CircleAlert, FileHeart, LoaderCircle } from "lucide-react";

export function LoadingState({ label = "Loading…" }: { label?: string }) { return <div className="card loading-card"><LoaderCircle size={17} className="spin" />{label}</div>; }
export function ErrorState({ label = "This section could not be loaded." }: { label?: string }) { return <div className="card error-panel"><CircleAlert size={18} /><span>{label}</span></div>; }
export function EmptyState({ title, detail, action }: { title: string; detail: string; action?: React.ReactNode }) { return <div className="card section-empty"><span className="section-empty-icon"><FileHeart size={21} /></span><h2>{title}</h2><p>{detail}</p>{action}</div>; }
