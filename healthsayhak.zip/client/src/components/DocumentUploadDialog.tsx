import { useEffect, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { w } from "@/lib/workflowCopy";
import { healthBoundaryText } from "@shared/healthBoundaryCopy";
import type { ExtractedHealthDocument, ExtractedMedication, HealthDocumentSummary, HealthLanguage } from "@shared/health";
import { AlertTriangle, ArrowLeft, Check, FileText, LoaderCircle, ShieldCheck, UploadCloud, X } from "lucide-react";
import { toast } from "sonner";

const empty = (value: string | undefined | null) => value ?? "";

export function DocumentUploadDialog({ open, onClose, language = "en", camera = false, initialDraft = null }: { open: boolean; onClose: () => void; language?: HealthLanguage; camera?: boolean; initialDraft?: HealthDocumentSummary | null }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();
  const analyze = trpc.documents.analyze.useMutation();
  const confirm = trpc.documents.confirm.useMutation({ onSuccess: async () => { await utils.health.overview.invalidate(); toast.success(w(language, "savedSuccess")); onClose(); reset(); } });
  const [file, setFile] = useState<File | null>(null);
  const [dataUrl, setDataUrl] = useState("");
  const [consent, setConsent] = useState(false);
  const [extraction, setExtraction] = useState<{ id: number; fileName: string; mimeType: string; extracted: ExtractedHealthDocument } | null>(null);
  const [edited, setEdited] = useState<ExtractedHealthDocument | null>(null);
  const [phase, setPhase] = useState<"choose" | "consent" | "processing" | "review" | "saving">("choose");
  const copy = (key: Parameters<typeof w>[1]) => w(language, key);
  const reset = () => { setFile(null); setDataUrl(""); setConsent(false); setExtraction(null); setEdited(null); setPhase("choose"); };
  useEffect(() => {
    if (!open) return;
    if (initialDraft?.status === "review" && initialDraft.summary) {
      setFile(null); setDataUrl(""); setConsent(true);
      setExtraction({ id: initialDraft.id, fileName: initialDraft.fileName, mimeType: initialDraft.mimeType, extracted: initialDraft.summary });
      setEdited(initialDraft.summary); setPhase("review");
    } else reset();
  }, [open, initialDraft?.id]);
  if (!open) return null;

  const close = () => { if (phase === "processing" || phase === "saving") return; reset(); onClose(); };

  const onPick = (picked?: File) => {
    if (!picked) return;
    const accepted = ["application/pdf", "image/jpeg", "image/png"].includes(picked.type);
    if (!accepted) { toast.error(copy("chooseFormat")); return; }
    if (picked.size > 8 * 1024 * 1024) { toast.error(copy("fileTooLarge")); return; }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== "string") { toast.error(copy("fileReadError")); return; }
      setFile(picked); setDataUrl(reader.result); setConsent(false); setPhase("consent");
    };
    reader.onerror = () => toast.error(copy("fileReadError"));
    reader.readAsDataURL(picked);
  };

  const startAnalysis = async () => {
    if (!file || !consent) return;
    setPhase("processing");
    try {
      const result = await analyze.mutateAsync({ fileName: file.name, mimeType: file.type as "application/pdf" | "image/jpeg" | "image/png", base64: dataUrl, language, consentAccepted: true });
      setExtraction(result); setEdited(result.extracted); setPhase("review");
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      toast.error(message.includes("not_health_document") ? healthBoundaryText(language, "notHealthDocument") : message || copy("analysisFailedMessage"));
      setPhase("consent");
    }
  };

  const saveReviewed = async () => {
    if (!extraction || !edited) return;
    setPhase("saving");
    try { await confirm.mutateAsync({ documentId: extraction.id, edited }); }
    catch (error) { setPhase("review"); toast.error(error instanceof Error ? error.message : copy("saveFailed")); }
  };

  const patch = <K extends keyof ExtractedHealthDocument>(key: K, value: ExtractedHealthDocument[K]) => setEdited(previous => previous ? { ...previous, [key]: value } : previous);
  const updateObservation = (index: number, key: "test" | "value" | "unit" | "referenceRange", value: string) => {
    setEdited(previous => previous ? { ...previous, observations: previous.observations.map((item, i) => i === index ? { ...item, [key]: value, outsideRange: null } : item) } : previous);
  };
  const updateMedication = (index: number, key: keyof ExtractedMedication, value: string) => {
    setEdited(previous => previous ? { ...previous, medications: previous.medications.map((item, i) => i === index ? { ...item, [key]: value } : item) } : previous);
  };
  const updateList = (key: "symptoms" | "assessments" | "recommendations" | "diagnoses" | "procedures" | "followUpInstructions" | "importantFindings", value: string) => {
    patch(key, value.split("\n").map(line => line.trim()).filter(Boolean));
  };

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) close(); }}>
      <section className="upload-modal" role="dialog" aria-modal="true" aria-labelledby="upload-title">
        <div className="modal-heading"><div><span className="page-kicker">{copy("reviewKicker")}</span><h2 id="upload-title">{phase === "review" || phase === "saving" ? copy("reviewTitle") : camera ? copy("scanTitle") : copy("addRecordTitle")}</h2></div><button className="icon-button" onClick={close} aria-label={copy("close")} disabled={phase === "processing" || phase === "saving"}><X size={19} /></button></div>

        {phase === "choose" && <><div className="upload-dropzone" onClick={() => inputRef.current?.click()} onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); onPick(event.dataTransfer.files[0]); }}><span className="upload-icon"><UploadCloud size={23} /></span><strong>{copy("chooseFileTitle")}</strong><p>{copy("browseDrop")}</p><span className="button button-secondary button-small">{copy("chooseDocument")}</span></div></>}
        <input ref={inputRef} className="visually-hidden" type="file" accept={camera ? "image/*" : ".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png"} capture={camera ? "environment" : undefined} onChange={event => onPick(event.currentTarget.files?.[0])} />

        {phase === "consent" && file && <div className="consent-stage"><div className="selected-file"><span className="icon-tile"><FileText size={18} /></span><span><strong>{file.name}</strong><small>{(file.size / 1024 / 1024).toFixed(2)} MB · {file.type === "application/pdf" ? "PDF" : "Image"}</small></span><button className="icon-button" onClick={() => { reset(); }} aria-label={copy("chooseDocument")}><ArrowLeft size={16} /></button></div><div className="privacy-callout"><ShieldCheck size={17} /><div><strong>{copy("processingPrivacyLabel")}</strong><p>{healthBoundaryText(language, "documentDisclosure")}</p></div></div><label className="consent-check"><input type="checkbox" checked={consent} onChange={event => setConsent(event.target.checked)} /><span>{copy("syntheticConsent")}</span></label><button className="button button-primary modal-main-action" onClick={() => void startAnalysis()} disabled={!consent}><SparkleMark />{copy("analyze")}</button></div>}

        {phase === "processing" && <div className="processing-stage"><span className="processing-glyph"><LoaderCircle size={27} className="spin" /></span><h3>{copy("understandingDocument")}</h3><p>{healthBoundaryText(language, "checkHealthDocument")}</p><div className="process-steps"><span className="done">{copy("uploadStep")}</span><i /><span className="current">{copy("extractStep")}</span><i /><span>{copy("reviewStep")}</span><i /><span>{copy("confirmStep")}</span></div><p className="tiny muted">{copy("draftReminder")}</p></div>}

        {(phase === "review" || phase === "saving") && edited && <div className="review-stage"><div className="review-source"><FileText size={15} /><span>{extraction?.fileName}</span><span className="status-pill warning">{copy("needsReview")}</span></div><div className="review-warning"><AlertTriangle size={15} /><span>{copy("compareWarning")}</span></div><div className="review-form"><label>{copy("documentTitle")}<input value={empty(edited.title)} onChange={event => patch("title", event.target.value)} maxLength={255} /></label><label>{copy("documentDate")}<input value={empty(edited.documentDate)} onChange={event => patch("documentDate", event.target.value)} placeholder={copy("notFoundInDocument")} /></label><label>{copy("documentType")}<select value={edited.kind} onChange={event => patch("kind", event.target.value as ExtractedHealthDocument["kind"])}><option value="lab_report">{copy("labReport")}</option><option value="prescription">{copy("prescriptionType")}</option><option value="doctor_note">{copy("doctorNote")}</option><option value="discharge_summary">{copy("dischargeSummary")}</option><option value="insurance">{copy("insuranceType")}</option><option value="medical_record">{copy("medicalRecord")}</option><option value="wellness">{copy("wellnessType")}</option><option value="other">{copy("otherType")}</option></select></label></div>
          <div className="review-section-title">{copy("foundInfo")}</div>
          <div className="review-subsection"><h3>{copy("documentDetails")}</h3><div className="review-edit-grid"><label className="field"><span>{copy("providerShown")}</span><input value={edited.provider} onChange={event => patch("provider", event.target.value)} maxLength={200} /></label>{edited.kind === "insurance" && <label className="field"><span>{copy("insuranceProvider")}</span><input value={edited.insuranceProvider} onChange={event => patch("insuranceProvider", event.target.value)} maxLength={180} /></label>}</div></div>
          {edited.observations.length > 0 && <div className="review-subsection"><h3>{copy("testResults")}</h3><div className="review-observations">{edited.observations.map((item, index) => <div className="review-observation" key={`${item.test}-${index}`}><div className="review-observation-head"><input aria-label={copy("testName")} value={item.test} onChange={event => updateObservation(index, "test", event.target.value)} /><span className={item.outsideRange === null ? "range-flag" : item.outsideRange ? "range-flag" : "range-okay"}>{item.outsideRange === null ? copy("recheckEdits") : item.outsideRange ? copy("outsideRange") : copy("withinRange")}</span></div><div className="review-observation-values"><input aria-label={copy("result")} value={item.value} onChange={event => updateObservation(index, "value", event.target.value)} /><input aria-label={copy("unit")} value={item.unit} onChange={event => updateObservation(index, "unit", event.target.value)} /><input aria-label={copy("referenceRange")} value={item.referenceRange} onChange={event => updateObservation(index, "referenceRange", event.target.value)} placeholder={copy("rangeNotFound")} /></div><small>{copy("sourceText")}: {item.sourceText || copy("notQuoted")}</small></div>)}</div><div className="range-caution">{copy("rangeCaution")}</div></div>}
          {edited.medications.length > 0 && <div className="review-subsection"><h3>{copy("medicationDetails")}</h3>{edited.medications.map((item, index) => <div className="review-edit-grid medication-edit" key={`${item.name}-${index}`}><label className="field"><span>{copy("medicine")}</span><input value={item.name} onChange={event => updateMedication(index, "name", event.target.value)} /></label><label className="field"><span>{copy("dosage")}</span><input value={item.dosage} onChange={event => updateMedication(index, "dosage", event.target.value)} /></label><label className="field"><span>{copy("frequency")}</span><input value={item.frequency} onChange={event => updateMedication(index, "frequency", event.target.value)} /></label><label className="field"><span>{copy("instructions")}</span><input value={item.instructions} onChange={event => updateMedication(index, "instructions", event.target.value)} /></label><label className="field"><span>{copy("duration")}</span><input value={item.duration} onChange={event => updateMedication(index, "duration", event.target.value)} /></label><label className="field"><span>{copy("prescribingDoctor")}</span><input value={item.prescribedBy} onChange={event => updateMedication(index, "prescribedBy", event.target.value)} /></label><p className="tiny muted field-full">{copy("sourceText")}: {item.sourceText || copy("notQuoted")}</p></div>)}</div>}
          {(edited.kind === "doctor_note" || edited.kind === "medical_record") && <div className="review-subsection"><h3>{copy("doctorNoteDetails")}</h3><div className="review-edit-grid"><label className="field"><span>{copy("symptomsInSource")}</span><textarea value={edited.symptoms.join("\n")} onChange={event => updateList("symptoms", event.target.value)} /></label><label className="field"><span>{copy("assessmentInSource")}</span><textarea value={edited.assessments.join("\n")} onChange={event => updateList("assessments", event.target.value)} /></label><label className="field"><span>{copy("diagnosesInSource")}</span><textarea value={edited.diagnoses.join("\n")} onChange={event => updateList("diagnoses", event.target.value)} /></label><label className="field"><span>{copy("recommendationsInSource")}</span><textarea value={edited.recommendations.join("\n")} onChange={event => updateList("recommendations", event.target.value)} /></label></div></div>}
          {edited.kind === "discharge_summary" && <div className="review-subsection"><h3>{copy("dischargeDetails")}</h3><div className="review-edit-grid"><label className="field"><span>{copy("admissionDate")}</span><input value={edited.admissionDate} onChange={event => patch("admissionDate", event.target.value)} /></label><label className="field"><span>{copy("dischargeDate")}</span><input value={edited.dischargeDate} onChange={event => patch("dischargeDate", event.target.value)} /></label><label className="field"><span>{copy("diagnosesInSource")}</span><textarea value={edited.diagnoses.join("\n")} onChange={event => updateList("diagnoses", event.target.value)} /></label><label className="field"><span>{copy("proceduresInSource")}</span><textarea value={edited.procedures.join("\n")} onChange={event => updateList("procedures", event.target.value)} /></label><label className="field field-full"><span>{copy("followUpInSource")}</span><textarea value={edited.followUpInstructions.join("\n")} onChange={event => updateList("followUpInstructions", event.target.value)} /></label></div></div>}
          {edited.kind === "insurance" && <div className="review-subsection"><h3>{copy("insuranceDetails")}</h3><div className="review-edit-grid"><label className="field field-full"><span>{copy("policyInformation")}</span><textarea value={edited.policyInformation} onChange={event => patch("policyInformation", event.target.value)} maxLength={600} /></label></div></div>}
          <div className="review-summary"><span className="section-label">{copy("importantFindings")}</span><p className="tiny muted">Edit one item per line.</p><textarea value={edited.importantFindings.join("\n")} onChange={event => updateList("importantFindings", event.target.value)} aria-label={copy("importantFindings")} /><span className="section-label">{copy("whatThisMeans")}</span><textarea value={edited.whatThisMeans} onChange={event => patch("whatThisMeans", event.target.value)} aria-label={copy("simpleSummary")} /><span className="section-label">{copy("sourceLabel")}</span><input value={edited.sourceNote} onChange={event => patch("sourceNote", event.target.value)} aria-label={copy("sourceLabel")} /></div>
          {edited.confidenceNote && <p className="tiny muted">{edited.confidenceNote}</p>}
          <div className="modal-actions"><button className="button button-secondary" onClick={() => { reset(); onClose(); }} disabled={phase === "saving"}>{copy("cancel")}</button><button className="button button-primary" onClick={() => void saveReviewed()} disabled={phase === "saving" || !edited.title.trim()}>{phase === "saving" ? <><LoaderCircle size={15} className="spin" />{copy("saving")}</> : <><Check size={15} />{copy("confirmSave")}</>}</button></div>
        </div>}
      </section>
    </div>
  );
}

function SparkleMark() { return <span className="sparkle-mark" aria-hidden="true">✦</span>; }
