import type { HealthLanguage } from "@shared/health";

const copy = {
  en: {
    home: "Home", copilot: "Copilot", vault: "Health Vault", journey: "Journey", profile: "Profile",
    morning: "Good morning", afternoon: "Good afternoon", evening: "Good evening", welcome: "Your health, in context.", homeSub: "A little clarity for the next step in your care.",
    ask: "Ask Copilot", voice: "Voice", addRecord: "Add a health record", today: "Today", attention: "Needs your attention",
    copilotQuestion: "How can I help with your health today?", copilotHint: "Ask about a report, an appointment, or what is already in your records.", reportMeaning: "What does my latest report mean?", lastAppointment: "What happened in my last appointment?", whatNext: "What should I do next?", recordedMeds: "What medications are currently recorded?", askPlaceholder: "Ask a question about your health", connectedJourney: "Connected to your journey", reportCount: "Reports", careEventsCount: "Care events", nothingAttention: "Nothing needs your attention right now.", nextStepsLink: "View next steps",
    suggested: "A few things you can ask", lastVisit: "What happened in my last appointment?", latestReport: "Explain my latest report.", meds: "What medications are currently recorded?", nextStep: "What do I need to do next?",
    journeyPreview: "Your healthcare journey", viewJourney: "View full journey", tasks: "Your next steps", appointments: "Upcoming appointment", medicationReminder: "Medication reminder", checkPrescriptionTiming: "Check the timing on the source prescription.",
    demoTitle: "See how the journey connects", demoText: "Explore a synthetic report, its extracted findings and a source-aware Copilot response. Demo values are not patient data.",
    demoLoad: "Explore the sample demo", synthetic: "Synthetic example", noRecords: "Your records will appear here after you add and confirm them.",
    safety: "HealthSahayak helps explain and organize records. It does not diagnose or replace a healthcare professional.",
    search: "Search records", newest: "Newest first", oldest: "Oldest first", all: "All", reports: "Reports", prescriptions: "Prescriptions", doctorNotes: "Doctor notes", discharge: "Discharge", insurance: "Insurance",
    processing: "Processing", listening: "Listening", speaking: "Speaking", whatWeKnow: "What we know", general: "General information", uncertain: "What is uncertain", why: "Why am I seeing this?", source: "Source", summary: "Simple-language summary", confirmSave: "Confirm & save", edit: "Edit",
  },
  te: {
    home: "హోమ్", copilot: "కోపైలట్", vault: "ఆరోగ్య భద్రం", journey: "ప్రయాణం", profile: "ప్రొఫైల్",
    morning: "శుభోదయం", afternoon: "శుభ మధ్యాహ్నం", evening: "శుభ సాయంత్రం", welcome: "మీ ఆరోగ్యం, పూర్తి సందర్భంతో.", homeSub: "మీ సంరక్షణలో తదుపరి అడుగుకు కొంత స్పష్టత.",
    ask: "కోపైలట్‌ను అడగండి", voice: "వాయిస్", addRecord: "ఆరోగ్య రికార్డు జోడించండి", today: "ఈ రోజు", attention: "మీ దృష్టి అవసరం",
    copilotQuestion: "ఈ రోజు మీ ఆరోగ్యం గురించి నేను ఎలా సహాయం చేయగలను?", copilotHint: "నివేదిక, అపాయింట్‌మెంట్ లేదా మీ రికార్డుల్లో ఉన్న విషయాల గురించి అడగండి.", reportMeaning: "నా తాజా నివేదిక అర్థం ఏమిటి?", lastAppointment: "నా చివరి అపాయింట్‌మెంట్‌లో ఏమైంది?", whatNext: "తర్వాత నేను ఏమి చేయాలి?", recordedMeds: "ప్రస్తుతం ఏ మందులు నమోదు అయ్యాయి?", askPlaceholder: "మీ ఆరోగ్యం గురించి ఒక ప్రశ్న అడగండి", connectedJourney: "మీ ప్రయాణంతో అనుసంధానం", reportCount: "నివేదికలు", careEventsCount: "సంరక్షణ సంఘటనలు", nothingAttention: "ప్రస్తుతం మీ దృష్టి అవసరమైనది ఏదీ లేదు.", nextStepsLink: "తదుపరి పనులు చూడండి",
    suggested: "మీరు అడగవచ్చినవి", lastVisit: "నా చివరి అపాయింట్‌మెంట్‌లో ఏమైంది?", latestReport: "నా తాజా నివేదికను వివరించండి.", meds: "ప్రస్తుతం ఏ మందులు నమోదు అయ్యాయి?", nextStep: "తర్వాత నేను ఏమి చేయాలి?",
    journeyPreview: "మీ ఆరోగ్య ప్రయాణం", viewJourney: "పూర్తి ప్రయాణం చూడండి", tasks: "మీ తదుపరి పనులు", appointments: "రాబోయే అపాయింట్‌మెంట్", medicationReminder: "మందుల గుర్తు", checkPrescriptionTiming: "సమయం కోసం మూల ప్రిస్క్రిప్షన్‌ను చూడండి.",
    demoTitle: "ఆరోగ్య ప్రయాణం ఎలా కలుస్తుందో చూడండి", demoText: "ఉదాహరణ నివేదిక, దాని నుంచి గుర్తించిన అంశాలు, మూలాన్ని చూపే కోపైలట్ సమాధానాన్ని చూడండి. ఇవి రోగి డేటా కావు.",
    demoLoad: "ఉదాహరణను చూడండి", synthetic: "కృత్రిమ ఉదాహరణ", noRecords: "మీరు రికార్డును జోడించి నిర్ధారించిన తర్వాత అది ఇక్కడ కనిపిస్తుంది.",
    safety: "HealthSahayak రికార్డులను అర్థం చేసుకోవడంలో, క్రమబద్ధం చేయడంలో సహాయపడుతుంది. ఇది రోగనిర్ధారణ చేయదు లేదా వైద్యుడికి ప్రత్యామ్నాయం కాదు.",
    search: "రికార్డులను వెతకండి", newest: "కొత్తవి ముందు", oldest: "పాతవి ముందు", all: "అన్నీ", reports: "నివేదికలు", prescriptions: "ప్రిస్క్రిప్షన్లు", doctorNotes: "వైద్యుని గమనికలు", discharge: "డిశ్చార్జ్", insurance: "బీమా",
    processing: "ప్రాసెస్ అవుతోంది", listening: "వింటోంది", speaking: "మాట్లాడుతోంది", whatWeKnow: "మనకు తెలిసినది", general: "సాధారణ సమాచారం", uncertain: "తెలియనిది", why: "ఈ సమాధానం ఎందుకు?", source: "మూలం", summary: "సరళమైన సారాంశం", confirmSave: "నిర్ధారించి భద్రపరచండి", edit: "సవరించండి",
  },
  hi: {
    home: "होम", copilot: "कोपायलट", vault: "हेल्थ वॉल्ट", journey: "जर्नी", profile: "प्रोफ़ाइल",
    morning: "सुप्रभात", afternoon: "नमस्कार", evening: "शुभ संध्या", welcome: "आपका स्वास्थ्य, पूरे संदर्भ के साथ।", homeSub: "आपकी देखभाल के अगले कदम के लिए थोड़ी स्पष्टता।",
    ask: "कोपायलट से पूछें", voice: "आवाज़", addRecord: "स्वास्थ्य रिकॉर्ड जोड़ें", today: "आज", attention: "आपके ध्यान की ज़रूरत",
    copilotQuestion: "आज मैं आपके स्वास्थ्य में कैसे मदद कर सकता हूँ?", copilotHint: "रिपोर्ट, अपॉइंटमेंट या आपके रिकॉर्ड में दर्ज बातों के बारे में पूछें।", reportMeaning: "मेरी नवीनतम रिपोर्ट का क्या अर्थ है?", lastAppointment: "मेरी पिछली अपॉइंटमेंट में क्या हुआ था?", whatNext: "मुझे आगे क्या करना चाहिए?", recordedMeds: "अभी कौन-सी दवाएँ दर्ज हैं?", askPlaceholder: "अपने स्वास्थ्य के बारे में प्रश्न पूछें", connectedJourney: "आपकी स्वास्थ्य यात्रा से जुड़ा", reportCount: "रिपोर्ट", careEventsCount: "देखभाल की घटनाएँ", nothingAttention: "अभी किसी बात पर आपका ध्यान देने की ज़रूरत नहीं है।", nextStepsLink: "अगले कदम देखें",
    suggested: "आप ये पूछ सकते हैं", lastVisit: "मेरी पिछली अपॉइंटमेंट में क्या हुआ था?", latestReport: "मेरी नवीनतम रिपोर्ट समझाएँ।", meds: "अभी कौन-सी दवाएँ दर्ज हैं?", nextStep: "मुझे आगे क्या करना चाहिए?",
    journeyPreview: "आपकी स्वास्थ्य यात्रा", viewJourney: "पूरी यात्रा देखें", tasks: "आपके अगले कदम", appointments: "आगामी अपॉइंटमेंट", medicationReminder: "दवा की याद", checkPrescriptionTiming: "समय देखने के लिए मूल प्रिस्क्रिप्शन देखें।",
    demoTitle: "देखें, आपकी स्वास्थ्य यात्रा कैसे जुड़ती है", demoText: "एक कृत्रिम रिपोर्ट, उससे निकली जानकारी और स्रोत दिखाने वाला कोपायलट उत्तर देखें। यह रोगी डेटा नहीं है।",
    demoLoad: "उदाहरण डेमो देखें", synthetic: "कृत्रिम उदाहरण", noRecords: "रिकॉर्ड जोड़कर पुष्टि करने के बाद वे यहाँ दिखाई देंगे।",
    safety: "HealthSahayak रिकॉर्ड समझने और व्यवस्थित करने में मदद करता है। यह निदान नहीं करता और स्वास्थ्य पेशेवर का विकल्प नहीं है।",
    search: "रिकॉर्ड खोजें", newest: "नवीनतम पहले", oldest: "पुराने पहले", all: "सभी", reports: "रिपोर्ट", prescriptions: "प्रिस्क्रिप्शन", doctorNotes: "डॉक्टर नोट", discharge: "डिस्चार्ज", insurance: "बीमा",
    processing: "प्रक्रिया जारी", listening: "सुन रहा है", speaking: "बोल रहा है", whatWeKnow: "हमें क्या पता है", general: "सामान्य जानकारी", uncertain: "क्या अनिश्चित है", why: "यह उत्तर क्यों?", source: "स्रोत", summary: "सरल भाषा में सारांश", confirmSave: "पुष्टि करें और सहेजें", edit: "संपादित करें",
  },
} satisfies Record<HealthLanguage, Record<string, string>>;

export type CopyKey = keyof typeof copy.en;
export const t = (language: HealthLanguage | undefined, key: CopyKey) => copy[language ?? "en"][key];
