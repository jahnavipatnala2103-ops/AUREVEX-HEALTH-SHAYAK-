import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { DocumentUploadDialog } from "@/components/DocumentUploadDialog";
import { t } from "@/lib/i18n";
import { w } from "@/lib/workflowCopy";
import type { WorkflowCopyKey } from "@/lib/workflowCopy";
import type { DocumentKind, HealthDocumentSummary, HealthLanguage } from "@shared/health";
import { ArrowDownWideNarrow, ArrowUpWideNarrow, CalendarDays, Camera, FileHeart, FileText, Filter, FolderOpen, LoaderCircle, Search, ShieldCheck, Trash2, Upload, X } from "lucide-react";
import { healthBoundaryText } from "@shared/healthBoundaryCopy";
import { format } from "date-fns";
import { toast } from "sonner";

const categories = ["All", "Reports", "Prescriptions", "Doctor notes", "Discharge", "Insurance"] as const;
type Category = typeof categories[number];
const kindForCategory: Record<Exclude<Category, "All">, DocumentKind[]> = { Reports: ["lab_report"], Prescriptions: ["prescription"], "Doctor notes": ["doctor_note"], Discharge: ["discharge_summary"], Insurance: ["insurance"] };
const dateLabel = (value: string | null, language: HealthLanguage) => value ? format(new Date(value), "MMM d, yyyy") : w(language, "dateNotFound");
const kindCopyKey: Record<DocumentKind, WorkflowCopyKey> = { lab_report: "labReport", prescription: "prescriptionType", doctor_note: "doctorNote", discharge_summary: "dischargeSummary", insurance: "insuranceType", medical_record: "medicalRecord", wellness: "wellnessType", other: "otherType" };
const kindLabel = (language: HealthLanguage, kind: DocumentKind) => w(language, kindCopyKey[kind]);

export default function HealthVault() {
  const [location, navigate] = useLocation();
  const overview = trpc.health.overview.useQuery();
  const utils = trpc.useUtils();
  const [category, setCategory] = useState<Category>("All");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<"newest" | "oldest">("newest");
  const [dialog, setDialog] = useState(false);
  const [camera, setCamera] = useState(false);
  const [selectedDraft, setSelectedDraft] = useState<HealthDocumentSummary | null>(null);
  const [requestedSource, setRequestedSource] = useState<HealthDocumentSummary | null>(null);
  const removeDocument = trpc.documents.remove.useMutation({
    onSuccess: async () => { await utils.health.overview.invalidate(); toast.success(healthBoundaryText(language, "deleteSuccess")); },
    onError: () => toast.error(healthBoundaryText(language, "deleteError")),
  });

  const language: HealthLanguage = overview.data?.profile.preferredLanguage ?? "en";
  const documents = useMemo(() => {
    const all = overview.data?.documents ?? [];
    const filtered = all.filter(doc => {
      const categoryOk = category === "All" || kindForCategory[category].includes(doc.kind);
      const query = search.trim().toLowerCase();
      const searchOk = !query || `${doc.fileName} ${kindLabel("en", doc.kind)} ${doc.summary?.title ?? ""} ${doc.summary?.provider ?? ""}`.toLowerCase().includes(query);
      return categoryOk && searchOk;
    });
    return filtered.sort((a, b) => sort === "newest" ? +new Date(b.uploadedAt) - +new Date(a.uploadedAt) : +new Date(a.uploadedAt) - +new Date(b.uploadedAt));
  }, [overview.data?.documents, category, search, sort]);

  const openSource = async (id: number) => {
    const win = window.open("about:blank", "_blank");
    try { const file = await utils.documents.sourceFile.fetch({ documentId: id }); if (win) { win.document.title = file.fileName; win.document.write(`<iframe title="${file.fileName.replace(/[<>"']/g, "")}" src="${file.dataUrl}" style="border:0;width:100vw;height:100vh"></iframe>`); } else toast("Allow pop-ups to view the source document."); }
    catch (error) { win?.close(); toast.error(error instanceof Error ? error.message : w(language, "sourceNotAvailable")); }
  };

  const requestDocumentRemoval = (document: HealthDocumentSummary) => {
    if (document.isDemo || removeDocument.isPending) return;
    if (!window.confirm(healthBoundaryText(language, "deleteConfirm"))) return;
    removeDocument.mutate({ documentId: document.id });
  };

  useEffect(() => {
    if (!location.startsWith("/vault")) return;
    const params = new URLSearchParams(window.location.search);
    if (params.get("upload") === "1") {
      setSelectedDraft(null); setCamera(false); setDialog(true); window.history.replaceState(null, "", "/vault"); return;
    }
    const targetId = Number(params.get("document"));
    if (!params.has("document") || !overview.data?.documents) return;
    const target = overview.data.documents.find(document => document.id === targetId);
    if (target?.status === "review") { setSelectedDraft(target); setCamera(false); setDialog(true); }
    else if (target) setRequestedSource(target);
    else toast.error(w(language, "sourceNotAvailable"));
    window.history.replaceState(null, "", "/vault");
  }, [location, overview.data?.documents]);

  return <div className="vault-page">
    <div className="page-heading vault-heading"><div><p className="page-kicker">{w(language, "vaultKicker")}</p><h1>{w(language, "vaultTitle")}</h1><p>{w(language, "vaultDescription")}</p></div><div className="vault-actions"><button className="button button-secondary" onClick={() => { setSelectedDraft(null); setCamera(true); setDialog(true); }}><Camera size={15} />{w(language, "scan")}</button><button className="button button-primary" onClick={() => { setSelectedDraft(null); setCamera(false); setDialog(true); }}><Upload size={15} />{w(language, "upload")}</button></div></div>
    <div className="vault-data-note"><ShieldCheck size={15} /><span>{w(language, "vaultDataNotice")}</span></div>
    <section className="vault-toolbar card"><div className="category-tabs" role="tablist" aria-label={w(language, "filterDocuments")}>{categories.map(option => <button key={option} className={category === option ? "active" : ""} role="tab" aria-selected={category === option} onClick={() => setCategory(option)}>{t(language, option === "All" ? "all" : option === "Reports" ? "reports" : option === "Prescriptions" ? "prescriptions" : option === "Doctor notes" ? "doctorNotes" : option === "Discharge" ? "discharge" : "insurance")}</button>)}</div><div className="vault-filters"><label className="vault-search"><Search size={15} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder={t(language, "search")} /><span className="visually-hidden">{t(language, "search")}</span>{search && <button onClick={() => setSearch("")} aria-label={w(language, "clearSearch")}><X size={14} /></button>}</label><button className="sort-button" aria-label={w(language, "changeSort")} onClick={() => setSort(sort === "newest" ? "oldest" : "newest")}><Filter size={14} />{sort === "newest" ? <>{t(language, "newest")}<ArrowDownWideNarrow size={13} /></> : <>{t(language, "oldest")}<ArrowUpWideNarrow size={13} /></>}</button></div></section>

    {requestedSource && <div className="source-request-card card"><span><strong>{requestedSource.isDemo ? w(language, "syntheticTitle") : requestedSource.fileName}</strong><small>{requestedSource.isDemo ? w(language, "syntheticNoSource") : `${kindLabel(language, requestedSource.kind)} · ${dateLabel(requestedSource.documentDate, language)}`}</small></span>{!requestedSource.isDemo && <button className="button button-secondary button-small" onClick={() => void openSource(requestedSource.id)}><FileText size={14} />{w(language, "openOriginal")}</button>}<button className="icon-button" aria-label={w(language, "dismiss")} onClick={() => setRequestedSource(null)}><X size={15} /></button></div>}
    {overview.isLoading ? <div className="card loading-card"><LoaderCircle size={17} className="spin" />{w(language, "loadingVault")}</div> : overview.error ? <div className="card error-panel">{w(language, "vaultError")}</div> : documents.length === 0 ? <div className="vault-empty card"><span className="vault-empty-icon"><FolderOpen size={24} /></span><h2>{search || category !== "All" ? w(language, "noMatchingRecords") : w(language, "vaultReady")}</h2><p>{search || category !== "All" ? w(language, "tryAnotherSearch") : t(language, "noRecords")}</p>{!search && category === "All" && <button className="button button-secondary button-small" onClick={() => { setSelectedDraft(null); setCamera(false); setDialog(true); }}><Upload size={14} />{w(language, "uploadFirstDocument")}</button>}</div> : <div className="document-list">{documents.map(document => <article className="document-card card" key={document.id}><div className={`doc-kind-icon ${document.kind}`}><FileHeart size={20} /></div><div className="doc-main"><div className="doc-title-row"><div><span className="doc-type">{kindLabel(language, document.kind)}</span><h2>{document.summary?.title || document.fileName.replace(/\.[^.]+$/, "")}</h2></div><div className="doc-flags">{document.isDemo && <span className="demo-tag">{w(language, "syntheticTitle")}</span>}<span className={`status-pill ${document.status === "review" ? "warning" : document.status === "failed" ? "neutral" : ""}`}>{document.status === "confirmed" ? w(language, "confirmed") : document.status === "review" ? w(language, "needsReview") : w(language, "analysisFailed")}</span></div></div><div className="doc-meta"><span><CalendarDays size={13} />{dateLabel(document.documentDate, language)}</span><span><FileText size={13} />{document.fileName}</span>{document.summary?.provider && <span>{document.summary.provider}</span>}</div>
          {document.summary && <div className="doc-summary"><span className="section-label">{w(language, "importantFindings")}</span>{document.summary.importantFindings.length ? document.summary.importantFindings.map((finding, i) => <p key={i}>{finding}</p>) : <p>{w(language, "noFindings")}</p>}<div className="finding-chips">{document.summary.observations.slice(0, 3).map((item, i) => <span key={i} className={item.outsideRange ? "finding-chip outside" : "finding-chip"}>{item.test}: {item.value} {item.unit}{item.outsideRange ? ` · ${w(language, "outsideRange")}` : ""}</span>)}</div><div className="saved-summary-section"><span className="section-label">{w(language, "whatThisMeans")}</span><p>{document.summary.whatThisMeans || w(language, "noExplanation")}</p></div><div className="saved-summary-section"><span className="section-label">{w(language, "sourceLabel")}</span><p>{document.isDemo ? w(language, "syntheticNoSource") : `${document.fileName} · ${dateLabel(document.documentDate, language)}`}</p></div><p className="doc-caution">{w(language, "outsideRangeCaution")}</p></div>}
          <div className="doc-card-bottom">{document.status === "confirmed" ? <button className="inline-link" onClick={() => document.isDemo ? toast(w(language, "syntheticNoSource")) : void openSource(document.id)}><FileText size={13} />{w(language, "viewSource")}</button> : document.status === "review" ? <div className="draft-actions"><button className="inline-link" onClick={() => { setSelectedDraft(document); setCamera(false); setDialog(true); }}><FileText size={13} />{w(language, "reviewDraft")}</button><button className="inline-link" onClick={() => void openSource(document.id)}><FileText size={13} />{w(language, "viewOriginal")}</button></div> : <span className="tiny muted">{w(language, "analysisFailedMessage")}</span>}{!document.isDemo && <button type="button" className="inline-link danger-icon" disabled={removeDocument.isPending} aria-label={`${healthBoundaryText(language, "deleteButton")} ${document.fileName}`} onClick={() => requestDocumentRemoval(document)}><Trash2 size={13} />{healthBoundaryText(language, "deleteButton")}</button>}<span className="tiny muted">{w(language, "added")} {format(new Date(document.uploadedAt), "MMM d")}</span></div>
        </div></article>)}</div>}
    <DocumentUploadDialog open={dialog} camera={camera} language={language} initialDraft={selectedDraft} onClose={() => { setDialog(false); setSelectedDraft(null); void utils.health.overview.invalidate(); }} />
  </div>;
}
