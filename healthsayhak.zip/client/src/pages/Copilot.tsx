import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { t } from "@/lib/i18n";
import { w } from "@/lib/workflowCopy";
import { entryText } from "@/lib/entryCopy";
import { healthBoundaryText } from "@shared/healthBoundaryCopy";
import type { CopilotReply, HealthLanguage } from "@shared/health";
import { ArrowDown, ArrowLeft, ArrowRight, AudioLines, Check, ChevronDown, ChevronRight, CircleAlert, FileHeart, History, LoaderCircle, MessageCircleHeart, Mic, MicOff, Plus, Send, ShieldCheck, Sparkles, Volume2 } from "lucide-react";
import { toast } from "sonner";

type ChatMessage = { role: "user" | "assistant"; content: string | CopilotReply; sources?: CopilotReply["sources"]; error?: boolean; retryQuestion?: string };
type SpeechResult = { transcript: string };
type SpeechRecognitionLike = {
  lang: string; interimResults: boolean; maxAlternatives: number;
  onresult: ((event: { results: ArrayLike<ArrayLike<SpeechResult>> }) => void) | null;
  onerror: (() => void) | null; onend: (() => void) | null; start: () => void; stop: () => void;
};

const promptKeys = ["reportMeaning", "lastAppointment", "whatNext", "recordedMeds"] as const;
const speechCodes: Record<HealthLanguage, string> = { en: "en-IN", te: "te-IN", hi: "hi-IN" };
const languageNames: Record<HealthLanguage, string> = { en: "English", te: "తెలుగు", hi: "हिन्दी" };

export default function Copilot() {
  const [, navigate] = useLocation();
  const overview = trpc.health.overview.useQuery();
  const utils = trpc.useUtils();
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [selectedHistoryId, setSelectedHistoryId] = useState<number | null>(null);
  const [whyOpen, setWhyOpen] = useState<number | null>(null);
  const [voiceState, setVoiceState] = useState<"listening" | "processing" | "speaking" | null>(null);
  const historyOpenQuery = trpc.copilot.conversation.useQuery({ id: selectedHistoryId ?? 1 }, { enabled: selectedHistoryId !== null });
  const ask = trpc.copilot.ask.useMutation();
  const transcribe = trpc.speech.transcribe.useMutation();
  const updateLanguage = trpc.health.updateProfile.useMutation({ onSuccess: () => void utils.health.overview.invalidate() });
  const scrollRef = useRef<HTMLDivElement>(null);
  const autoLoaded = useRef(false);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recordingParts = useRef<Blob[]>([]);
  const recordingTimer = useRef<number | null>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const lang: HealthLanguage = overview.data?.profile.preferredLanguage ?? "en";
  const prompts = promptKeys.map(key => t(lang, key));

  useEffect(() => {
    if (autoLoaded.current) return;
    autoLoaded.current = true;
    const params = new URLSearchParams(window.location.search);
    const initialQuestion = params.get("ask");
    if (initialQuestion) setQuestion(initialQuestion);
    // Focus the control, but wait for a direct user gesture before requesting microphone access.
    if (params.get("voice") === "1") window.setTimeout(() => document.querySelector<HTMLButtonElement>(".compose-voice")?.focus(), 250);
  }, []);

  useEffect(() => {
    if (!historyOpenQuery.data || selectedHistoryId === null) return;
    const nextMessages = historyOpenQuery.data.messages.map(message => {
      let content: string | CopilotReply = message.content as string;
      if (message.role === "assistant" && typeof content === "string" && content.startsWith("{")) {
        try { content = JSON.parse(content) as CopilotReply; } catch { /* keep the original response */ }
      }
      return { role: message.role, content, sources: message.sources as CopilotReply["sources"] } as ChatMessage;
    });
    setMessages(nextMessages);
    setConversationId(historyOpenQuery.data.id);
    setSelectedHistoryId(null);
  }, [historyOpenQuery.data, selectedHistoryId]);

  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" }); }, [messages, ask.isPending]);

  const threadTitle = useMemo(() => overview.data?.conversations.find(item => item.id === conversationId)?.title, [overview.data?.conversations, conversationId]);
  const startBrowserRecognition = () => {
    const win = window as Window & { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike };
    const Constructor = win.SpeechRecognition ?? win.webkitSpeechRecognition;
    if (!Constructor) return false;
    try {
      const recognition = new Constructor();
      recognitionRef.current = recognition;
      recognition.lang = speechCodes[lang]; recognition.interimResults = false; recognition.maxAlternatives = 1;
      setVoiceState("listening");
      recognition.onresult = event => {
        const transcript = event.results?.[0]?.[0]?.transcript?.trim();
        if (transcript) { setQuestion(previous => [previous.trim(), transcript].filter(Boolean).join(" ")); toast.success(entryText(lang, "transcriptReady")); }
        setVoiceState(null);
      };
      recognition.onerror = () => { setVoiceState(null); toast.error(entryText(lang, "voiceInputError")); };
      recognition.onend = () => setVoiceState(null);
      recognition.start();
      return true;
    } catch { setVoiceState(null); return false; }
  };

  const beginListening = () => {
    if (voiceState === "listening") {
      if (recorderRef.current?.state === "recording") recorderRef.current.stop();
      else recognitionRef.current?.stop();
      return;
    }
    if (voiceState === "processing" || ask.isPending) return;
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      if (!startBrowserRecognition()) toast.error(entryText(lang, "voiceUnavailable"));
      return;
    }
    void (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        streamRef.current = stream;
        const candidates = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg;codecs=opus", "audio/ogg"];
        const mimeType = candidates.find(value => MediaRecorder.isTypeSupported(value));
        const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
        recorderRef.current = recorder;
        recordingParts.current = [];
        recorder.ondataavailable = event => { if (event.data.size) recordingParts.current.push(event.data); };
        recorder.onerror = () => { setVoiceState(null); stream.getTracks().forEach(track => track.stop()); streamRef.current = null; toast.error(entryText(lang, "voiceInputError")); };
        recorder.onstop = async () => {
          if (recordingTimer.current !== null) window.clearTimeout(recordingTimer.current);
          recordingTimer.current = null;
          stream.getTracks().forEach(track => track.stop());
          streamRef.current = null;
          const audio = new Blob(recordingParts.current, { type: recorder.mimeType || "audio/webm" });
          recordingParts.current = [];
          if (!audio.size) { setVoiceState(null); toast.error(entryText(lang, "noSpeech")); return; }
          if (audio.size > 8 * 1024 * 1024) { setVoiceState(null); toast.error(entryText(lang, "recordingTooLarge")); return; }
          setVoiceState("processing");
          try {
            const base64 = await blobAsBase64(audio);
            const result = await transcribe.mutateAsync({ base64, mimeType: audio.type || recorder.mimeType || "audio/webm", language: lang });
            setQuestion(previous => [previous.trim(), result.text.trim()].filter(Boolean).join(" "));
            toast.success(entryText(lang, "transcriptReady"));
          } catch (error) {
            toast.error(error instanceof Error ? error.message : entryText(lang, "voiceInputError"));
          } finally { setVoiceState(null); }
        };
        recorder.start(250);
        setVoiceState("listening");
        recordingTimer.current = window.setTimeout(() => { if (recorder.state === "recording") recorder.stop(); }, 15_000);
      } catch (error) {
        streamRef.current?.getTracks().forEach(track => track.stop());
        streamRef.current = null;
        if (error instanceof DOMException && error.name === "NotAllowedError") toast.error(entryText(lang, "microphonePermission"));
        else if (!startBrowserRecognition()) toast.error(entryText(lang, "voiceInputError"));
      }
    })();
  };

  useEffect(() => () => {
    if (recordingTimer.current !== null) window.clearTimeout(recordingTimer.current);
    if (recorderRef.current) { recorderRef.current.onstop = null; recorderRef.current.ondataavailable = null; if (recorderRef.current.state !== "inactive") recorderRef.current.stop(); }
    streamRef.current?.getTracks().forEach(track => track.stop());
    recognitionRef.current?.stop();
    window.speechSynthesis?.cancel();
  }, []);

  const speak = (reply: CopilotReply) => {
    if (!("speechSynthesis" in window)) { toast(w(lang, "voiceOutputUnavailable")); return; }
    const utterance = new SpeechSynthesisUtterance([...reply.whatWeKnow, reply.generalInformation, reply.uncertain, reply.nextStep].filter(Boolean).join(". "));
    utterance.lang = speechCodes[lang]; utterance.onstart = () => setVoiceState("speaking"); utterance.onend = () => setVoiceState(null); utterance.onerror = () => setVoiceState(null);
    window.speechSynthesis.cancel(); window.speechSynthesis.speak(utterance);
  };

  const sendQuestion = async (trimmed: string) => {
    if (!trimmed || ask.isPending) return;
    setQuestion(""); setVoiceState("processing");
    setMessages(previous => [...previous, { role: "user", content: trimmed }]);
    try {
      const result = await ask.mutateAsync({ question: trimmed, conversationId: conversationId ?? undefined, language: lang });
      setConversationId(result.conversationId);
      setMessages(previous => [...previous, { role: "assistant", content: result.reply, sources: result.reply.sources }]);
      setWhyOpen(null); await utils.health.overview.invalidate();
    } catch {
      const errorMessage = entryText(lang, "copilotRetryError");
      setMessages(previous => [...previous, { role: "assistant", content: errorMessage, error: true, retryQuestion: trimmed }]);
      setQuestion(trimmed);
    } finally { setVoiceState(null); }
  };

  const submitQuestion = (event?: FormEvent) => {
    event?.preventDefault();
    void sendQuestion(question.trim());
  };

  const startNewConversation = () => { setConversationId(null); setMessages([]); setQuestion(""); setWhyOpen(null); window.history.replaceState(null, "", "/copilot"); };
  const loadConversation = (id: number) => { setMessages([]); setSelectedHistoryId(id); };

  return (
    <div className="copilot-page">
      <div className="page-heading copilot-heading"><div><p className="page-kicker">{w(lang, "copilotKicker")}</p><h1>{w(lang, "copilotTitle")}</h1><p>{w(lang, "copilotDescription")}</p></div><button className="button button-secondary button-small" onClick={startNewConversation}><Plus size={14} />{w(lang, "newConversation")}</button></div>
      <div className="copilot-workspace">
        <aside className="conversation-rail card"><div className="conversation-rail-head"><span className="section-label">{w(lang, "conversations")}</span><History size={15} /></div><button className={`history-new ${!conversationId ? "active" : ""}`} onClick={startNewConversation}><MessageCircleHeart size={15} />{w(lang, "newConversation")}</button><div className="conversation-history">{overview.data?.conversations.map(item => <button key={item.id} className={`history-item ${item.id === conversationId ? "active" : ""}`} onClick={() => loadConversation(item.id)}><span className="history-bubble"><MessageCircleHeart size={13} /></span><span><strong>{item.title}</strong><small>{new Date(item.updatedAt).toLocaleDateString()}</small></span><ChevronRight size={13} /></button>)}</div><div className="context-notice"><ShieldCheck size={15} /><p><strong>{w(lang, "relevantOnly")}</strong><span>{w(lang, "relevantOnlyDescription")}</span></p></div></aside>

        <section className="chat-panel card" aria-label={w(lang, "copilotTitle")}>
          <div className="chat-panel-head"><span className="chat-avatar"><MessageCircleHeart size={18} /></span><div><strong>{threadTitle || w(lang, "copilotTitle")}</strong><small><span className="hero-live-dot" /> {w(lang, "relevantOnly")}</small></div><label className="chat-language"><span className="visually-hidden">{w(lang, "responseLanguage")}</span><select value={lang} onChange={event => { const next = event.target.value as HealthLanguage; updateLanguage.mutate({ preferredLanguage: next }); }}><option value="en">English</option><option value="te">తెలుగు</option><option value="hi">हिन्दी</option></select><ChevronDown size={12} /></label></div>

          <div className="chat-scroll" ref={scrollRef}>
            {messages.length === 0 ? <div className="chat-empty"><span className="chat-empty-icon"><Sparkles size={19} /></span><span className="page-kicker">{w(lang, "fromAnswersToContext")}</span><h2>{w(lang, "emptyPrompt")}</h2><p>{w(lang, "emptyDescription")}</p><div className="chat-prompt-list">{prompts.map(prompt => <button key={prompt} onClick={() => setQuestion(prompt)}>{prompt}<ArrowRight size={13} /></button>)}</div></div> : <div className="chat-messages">{messages.map((message, index) => <div key={`${index}-${message.role}`} className={`chat-message ${message.role}`}><div className="message-role">{message.role === "user" ? w(lang, "you") : <><MessageCircleHeart size={13} /> {w(lang, "assistant")}</>}</div>{message.role === "user" ? <div className="user-bubble">{typeof message.content === "string" ? message.content : ""}</div> : message.error ? <div className="assistant-inline-error" role="alert"><CircleAlert size={15} /><p>{typeof message.content === "string" ? message.content : ""}</p><button type="button" disabled={ask.isPending} onClick={() => void sendQuestion(message.retryQuestion ?? question)}>{ask.isPending ? <LoaderCircle size={13} className="spin" /> : null}{entryText(lang, "retryAnswer")}</button></div> : <AssistantReply reply={typeof message.content === "string" ? parseReply(message.content) : message.content} index={index} language={lang} open={whyOpen === index} onToggle={() => setWhyOpen(whyOpen === index ? null : index)} onOpenSource={documentId => navigate(`/vault?document=${documentId}`)} onSpeak={() => { const reply = typeof message.content === "string" ? parseReply(message.content) : message.content; if (reply) speak(reply); }} />}</div>)}</div>}
            {ask.isPending && <div className="assistant-thinking"><span className="chat-avatar small"><MessageCircleHeart size={14} /></span><span><i /><i /><i /></span><small>{w(lang, "checkingRecords")}</small></div>}
          </div>

          <div className="chat-compose-area"><div className="chat-safety-line"><ShieldCheck size={13} />{w(lang, "safetyLine")}</div><form className="chat-compose" onSubmit={event => void submitQuestion(event)}><button type="button" className={`compose-voice ${voiceState === "listening" ? "active" : ""}`} onClick={beginListening} disabled={voiceState === "processing" || ask.isPending} aria-label={voiceState === "listening" ? entryText(lang, "stopRecording") : w(lang, "startVoice")} title={voiceState === "listening" ? entryText(lang, "stopRecording") : w(lang, "startVoice")}>{voiceState === "listening" ? <MicOff size={17} /> : <Mic size={17} />}</button><input value={question} onChange={event => setQuestion(event.target.value)} maxLength={1600} placeholder={voiceState === "listening" ? w(lang, "listeningPlaceholder") : w(lang, "inputPlaceholder")} aria-label={w(lang, "askSahayak")} /><button className="compose-send" type="submit" disabled={!question.trim() || ask.isPending} aria-label={w(lang, "sendQuestion")}>{ask.isPending ? <LoaderCircle size={17} className="spin" /> : <Send size={17} />}</button></form><div className="chat-footer-row"><span>{voiceState ? `${t(lang, voiceState)} · ${languageNames[lang]}` : `${w(lang, "responsesIn")}: ${languageNames[lang]}`}</span><span>{w(lang, "checkSource")}</span></div><p className="voice-privacy-note">{entryText(lang, "voicePrivacy")}</p></div>
        </section>
      </div>
    </div>
  );
}

function blobAsBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("The recording could not be read."));
    reader.onload = () => {
      const value = reader.result;
      if (typeof value !== "string") { reject(new Error("The recording could not be read.")); return; }
      resolve(value.slice(value.indexOf(",") + 1));
    };
    reader.readAsDataURL(blob);
  });
}

function parseReply(raw: string): CopilotReply | null {
  try { const parsed = JSON.parse(raw) as CopilotReply; return parsed && Array.isArray(parsed.whatWeKnow) ? parsed : null; }
  catch { return null; }
}

function sourceKindLabel(kind: string, language: HealthLanguage) {
  if (kind === "observation") return w(language, "reports");
  if (kind === "medication") return w(language, "medications");
  if (kind === "appointment") return w(language, "appointments");
  if (kind === "encounter") return w(language, "consultations");
  if (kind === "follow-up task") return t(language, "tasks");
  if (kind === "insurance") return w(language, "insuranceType");
  if (kind === "discharge") return w(language, "dischargeSummary");
  if (kind === "wellness") return w(language, "wellnessType");
  return kind;
}

function AssistantReply({ reply, index, language, open, onToggle, onSpeak, onOpenSource }: { reply: CopilotReply | null; index: number; language: HealthLanguage; open: boolean; onToggle: () => void; onSpeak: () => void; onOpenSource: (documentId: number) => void }) {
  if (!reply) return <div className="assistant-raw">{w(language, "previousAnswerUnavailable")}</div>;
  const healthOnly = reply.whatWeKnow?.length === 1 && reply.whatWeKnow[0] === healthBoundaryText(language, "healthOnlyAnswer");
  return <div className="assistant-answer"><div className="assistant-answer-top"><span className="answer-status"><Check size={12} />{healthOnly ? healthBoundaryText(language, "healthOnlyLabel") : w(language, "recordAware")}</span><button className="speak-button" onClick={onSpeak} aria-label={w(language, "speakAnswer")}><Volume2 size={14} /></button></div>
    <section className="answer-section"><h3>{t(language, "whatWeKnow")}</h3>{reply.whatWeKnow.length ? <ul>{reply.whatWeKnow.map((item, i) => <li key={i}>{item}</li>)}</ul> : <p>{w(language, "noSupportingFacts")}</p>}</section>
    {reply.generalInformation && <section className="answer-section"><h3>{t(language, "general")}</h3><p>{reply.generalInformation}</p></section>}
    {reply.uncertain && <section className="answer-section uncertain-section"><h3><CircleAlert size={13} />{t(language, "uncertain")}</h3><p>{reply.uncertain}</p></section>}
    {reply.nextStep && <div className="next-step-card"><span className="next-step-marker"><ArrowRight size={14} /></span><div><strong>{w(language, "possibleNext")}</strong><p>{reply.nextStep}</p></div></div>}
    <button className="why-toggle" onClick={onToggle} aria-expanded={open}><FileHeart size={14} />{t(language, "why")}<span>{reply.sources.length} {reply.sources.length === 1 ? w(language, "source") : w(language, "sources")}</span><ChevronDown size={14} className={open ? "rotated" : ""} /></button>
    {open && <div className="source-list">{reply.sources.map(source => { const content = <><FileHeart size={14} /><span><strong>{source.title}</strong><small>{sourceKindLabel(source.kind, language)} · {source.date}</small></span><Check size={13} className="source-check" />{source.documentId ? <ChevronRight size={13} /> : null}</>; return source.documentId ? <button className="source-item source-link" key={source.id} onClick={() => onOpenSource(source.documentId!)}>{content}</button> : <div className="source-item" key={source.id}>{content}</div>; })}</div>}
    <p className="answer-disclaimer">{w(language, "answerDisclaimer")}</p>
  </div>;
}
