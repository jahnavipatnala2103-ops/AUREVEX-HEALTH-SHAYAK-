import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { BrandMark } from "@/components/BrandMark";
import { entryText } from "@/lib/entryCopy";
import type { HealthLanguage, ProfileSummary } from "@shared/health";
import { toast } from "sonner";
import { ArrowRight, HeartPulse, ShieldCheck } from "lucide-react";

const languages: { value: HealthLanguage; label: string }[] = [
  { value: "en", label: "English" },
  { value: "te", label: "తెలుగు" },
  { value: "hi", label: "हिन्दी" },
];
const bloodGroups = ["A+", "A−", "B+", "B−", "AB+", "AB−", "O+", "O−"];

type FormValues = {
  displayName: string;
  dateOfBirth: string;
  bloodGroup: string;
  allergies: string;
  emergencyName: string;
  emergencyPhone: string;
  emergencyInformation: string;
  preferredLanguage: HealthLanguage;
};

function calculateAge(value: string): number | null {
  if (!value) return null;
  const birth = new Date(`${value}T00:00:00`);
  const now = new Date();
  if (Number.isNaN(birth.getTime()) || birth > now) return null;
  let age = now.getFullYear() - birth.getFullYear();
  if (now.getMonth() < birth.getMonth() || (now.getMonth() === birth.getMonth() && now.getDate() < birth.getDate())) age -= 1;
  return age >= 0 && age < 130 ? age : null;
}

export default function Onboarding({ profile }: { profile: ProfileSummary }) {
  const utils = trpc.useUtils();
  const save = trpc.health.completeOnboarding.useMutation();
  const [form, setForm] = useState<FormValues>({
    displayName: profile.name === "HealthSahayak member" ? "" : profile.name,
    dateOfBirth: profile.dateOfBirth ?? "",
    bloodGroup: profile.bloodGroup ?? "",
    allergies: profile.allergies.join(", "),
    emergencyName: profile.emergencyName,
    emergencyPhone: profile.emergencyPhone,
    emergencyInformation: profile.emergencyInformation,
    preferredLanguage: profile.preferredLanguage ?? "en",
  });
  const language = form.preferredLanguage;
  const copy = (key: Parameters<typeof entryText>[1]) => entryText(language, key);
  const age = calculateAge(form.dateOfBirth);
  const set = <K extends keyof FormValues>(key: K, value: FormValues[K]) => setForm(previous => ({ ...previous, [key]: value }));
  const localToday = new Date();
  const today = `${localToday.getFullYear()}-${String(localToday.getMonth() + 1).padStart(2, "0")}-${String(localToday.getDate()).padStart(2, "0")}`;

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!form.displayName.trim()) { toast.error(copy("nameRequired")); return; }
    if (!form.dateOfBirth || age === null) { toast.error(copy("dateRequired")); return; }
    try {
      await save.mutateAsync({
        displayName: form.displayName.trim(), dateOfBirth: form.dateOfBirth,
        ...(form.bloodGroup.trim() ? { bloodGroup: form.bloodGroup.trim() } : {}),
        allergies: form.allergies.split(",").map(item => item.trim()).filter(Boolean),
        emergencyName: form.emergencyName.trim(), emergencyPhone: form.emergencyPhone.trim(), emergencyInformation: form.emergencyInformation.trim(),
        preferredLanguage: form.preferredLanguage,
      });
      await utils.health.overview.invalidate();
      toast.success(copy("continueToHealth"));
    } catch { toast.error(copy("setupFailed")); }
  };

  return (
    <main className="onboarding-screen">
      <header className="entry-header onboarding-header"><div className="entry-brand"><BrandMark /><span><strong>HealthSahayak</strong><small>{copy("brandLine")}</small></span></div><label className="entry-language"><span>{copy("language")}</span><select value={language} onChange={event => set("preferredLanguage", event.target.value as HealthLanguage)} aria-label={copy("language")}>{languages.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label></header>
      <section className="onboarding-card card">
        <div className="onboarding-intro"><span className="onboarding-icon"><HeartPulse size={21} /></span><p className="eyebrow">{copy("onboardingEyebrow")}</p><h1>{copy("onboardingTitle")}</h1><p>{copy("onboardingBody")}</p></div>
        <form onSubmit={submit} className="onboarding-form">
          <div className="onboarding-grid">
            <label className="field"><span>{copy("fullName")} <b aria-hidden="true">*</b></span><input required autoComplete="name" maxLength={180} value={form.displayName} onChange={event => set("displayName", event.target.value)} /></label>
            <label className="field"><span>{copy("birthDate")} <b aria-hidden="true">*</b></span><input required type="date" autoComplete="bday" max={today} value={form.dateOfBirth} onChange={event => set("dateOfBirth", event.target.value)} /><small>{copy("age")}: {age === null ? "—" : `${age} ${copy("yearsOld")}`}</small></label>
            <label className="field"><span>{copy("bloodGroup")}</span><select value={form.bloodGroup} onChange={event => set("bloodGroup", event.target.value)}><option value="">{copy("chooseBloodGroup")}</option>{bloodGroups.map(group => <option key={group} value={group}>{group}</option>)}</select><small>{copy("optional")}</small></label>
            <label className="field"><span>{copy("allergies")}</span><input value={form.allergies} onChange={event => set("allergies", event.target.value)} maxLength={600} placeholder={copy("allergyHint")} /><small>{copy("optional")}</small></label>
            <div className="onboarding-section-title"><ShieldCheck size={16} /><strong>{copy("emergencyTitle")}</strong><small>{copy("optional")}</small></div>
            <label className="field"><span>{copy("emergencyName")}</span><input autoComplete="name" value={form.emergencyName} onChange={event => set("emergencyName", event.target.value)} maxLength={160} /></label>
            <label className="field"><span>{copy("emergencyPhone")}</span><input autoComplete="tel" type="tel" value={form.emergencyPhone} onChange={event => set("emergencyPhone", event.target.value)} maxLength={48} /></label>
            <label className="field onboarding-full"><span>{copy("emergencyNotes")}</span><textarea value={form.emergencyInformation} onChange={event => set("emergencyInformation", event.target.value)} maxLength={1000} rows={2} /></label>
            <label className="field onboarding-full"><span>{copy("preferredLanguage")}</span><select value={form.preferredLanguage} onChange={event => set("preferredLanguage", event.target.value as HealthLanguage)}>{languages.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
          </div>
          <p className="onboarding-privacy"><ShieldCheck size={14} />{copy("setupPrivacy")}</p>
          <button className="button button-primary onboarding-submit" type="submit" disabled={save.isPending}>{save.isPending ? copy("saving") : <>{copy("continueToHealth")} <ArrowRight size={16} /></>}</button>
        </form>
      </section>
    </main>
  );
}
