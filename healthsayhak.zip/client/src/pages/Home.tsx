import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { t } from "@/lib/i18n";
import { w } from "@/lib/workflowCopy";
import { ArrowRight, CalendarDays, Check, ChevronRight, CircleAlert, Clock3, FileHeart, HeartPulse, MessageCircleHeart, Mic2, Pill, Plus, Sparkles, Waypoints } from "lucide-react";
import { format } from "date-fns";
import type { JourneyEventSummary } from "@shared/health";

const questionKeys = ["lastVisit", "latestReport", "meds", "nextStep"] as const;
const weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const appText = (date = new Date()) => `${weekdays[date.getDay()]}, ${format(date, "MMMM d")}`;
const formatDate = (date?: string | null) => date ? format(new Date(date), "MMM d") : "Date not recorded";

export default function Home() {
  const [, navigate] = useLocation();
  const query = trpc.health.overview.useQuery(undefined, { retry: 1 });
  const overview = query.data;
  const language = overview?.profile.preferredLanguage ?? "en";
  const firstName = overview?.profile.name?.split(" ")[0] ?? "there";
  const now = new Date();
  const greeting = now.getHours() < 12 ? t(language, "morning") : now.getHours() < 18 ? t(language, "afternoon") : t(language, "evening");
  const questions = questionKeys.map(key => t(language, key));
  const upcoming = overview?.records.find(record => record.kind === "appointment" && record.recordDate && new Date(record.recordDate) >= now);
  const latestMedication = overview?.records.find(record => record.kind === "medication");
  const activeTasks = overview?.tasks.filter(task => !task.completed) ?? [];
  const latestDocument = overview?.documents.find(document => document.status === "confirmed");
  const pendingDocument = overview?.documents.find(document => document.status === "review");
  const latestEvents = (overview?.events ?? []).slice(0, 3);

  const ask = (prompt: string) => navigate(`/copilot?ask=${encodeURIComponent(prompt)}`);
  const openVoice = () => navigate("/copilot?voice=1");

  if (query.isLoading) return <div className="skeleton-page"><div className="skeleton-block" /><div className="skeleton-grid"><div className="skeleton-block" /><div className="skeleton-block" /></div></div>;
  if (query.error) return <div className="error-panel"><CircleAlert size={20} /><div><strong>Your health space could not load.</strong><p>Refresh the page. No health record was changed.</p></div><button className="button button-secondary button-small" onClick={() => void query.refetch()}>Try again</button></div>;

  return (
    <div className="home-page">
      <div className="home-topline"><span className="page-kicker">{appText(now)}</span><span className="demo-tag">{t(language, "connectedJourney")}</span></div>
      <section className="home-greeting"><div><h1>{greeting}, {firstName}.</h1><p>{t(language, "homeSub")}</p></div><button className="button button-secondary" onClick={() => navigate("/vault?upload=1")}><Plus size={15} />{t(language, "addRecord")}</button></section>

      <section className="copilot-hero">
        <div className="copilot-hero-copy"><span className="hero-icon"><HeartPulse size={18} /></span><div className="hero-label">HEALTHSAYHAK COPILOT <span className="hero-live-dot" /></div><h2>{t(language, "copilotQuestion")}</h2><p>{t(language, "copilotHint")}</p>
          <div className="hero-input-row"><button className="hero-input" onClick={() => ask("")} aria-label="Open Copilot input">{t(language, "askPlaceholder")} <ArrowRight size={16} /></button><button className="button button-primary" onClick={() => navigate("/copilot")}>{t(language, "ask")} <ArrowRight size={15} /></button><button className="voice-button" onClick={openVoice} aria-label={t(language, "voice")}><Mic2 size={17} /><span>{t(language, "voice")}</span></button></div>
          <div className="suggested-label">{t(language, "suggested")}</div><div className="suggested-questions">{questions.map((question, index) => <button key={question} onClick={() => ask(question)}><span className="suggestion-number">0{index + 1}</span>{question}<ArrowRight size={13} /></button>)}</div>
        </div>
        <div className="hero-context"><div className="context-ring"><span><HeartPulse size={22} /></span><i /><i /><i /></div><div className="context-caption"><span className="context-dot" />{t(language, "connectedJourney")}</div><div className="context-source-list"><div><FileHeart size={14} /><span>{t(language, "reportCount")}</span><small>{overview?.documents.filter(doc => doc.status === "confirmed").length ?? 0}</small></div><div><Waypoints size={14} /><span>{t(language, "careEventsCount")}</span><small>{overview?.events.length ?? 0}</small></div></div></div>
      </section>

      {(overview?.documents.length ?? 0) === 0 && (
        <section className="demo-invitation">
          <div className="demo-invitation-icon"><Sparkles size={17} /></div>
          <div className="demo-invitation-copy"><strong>{t(language, "demoTitle")}</strong><p>{t(language, "demoText")}</p><span className="demo-tag">{w(language, "syntheticNoRecord")}</span></div>
          <button className="button button-secondary button-small" onClick={() => navigate("/demo")}><Sparkles size={14} />{t(language, "demoLoad")}</button>
        </section>
      )}

      <section className="home-section-grid">
        <div className="home-panel card">
          <div className="section-title"><div><span className="section-label">{t(language, "today")}</span><h2>{t(language, "attention")}</h2></div><span className="soft-count">{activeTasks.length + (upcoming ? 1 : 0) + (latestMedication ? 1 : 0) + (pendingDocument ? 1 : 0)}</span></div>
          <div className="today-list">
            {upcoming && <button className="today-row" onClick={() => navigate("/profile")}><span className="today-icon"><CalendarDays size={16} /></span><span><strong>{t(language, "appointments")}</strong><small>{String(upcoming.data.doctor ?? "Provider not recorded")} · {formatDate(upcoming.recordDate)}</small></span><ChevronRight size={15} /></button>}
            {latestMedication && <button className="today-row" onClick={() => navigate("/profile")}><span className="today-icon"><Pill size={16} /></span><span><strong>{t(language, "medicationReminder")}: {String(latestMedication.data.name ?? latestMedication.title)}</strong><small>{latestMedication.data.frequency ? `Recorded frequency: ${String(latestMedication.data.frequency)}` : t(language, "checkPrescriptionTiming")}</small></span><ChevronRight size={15} /></button>}
            {activeTasks.slice(0, 2).map(task => <button className="today-row" key={task.id} onClick={() => navigate("/profile")}><span className="today-icon warm"><Clock3 size={16} /></span><span><strong>{task.title}</strong><small>{task.dueDate ? `Due ${formatDate(task.dueDate)}` : "Follow-up"}</small></span><ChevronRight size={15} /></button>)}
            {pendingDocument && <button className="today-row" onClick={() => navigate(`/vault?document=${pendingDocument.id}`)}><span className="today-icon warm"><FileHeart size={16} /></span><span><strong>{w(language, "reviewDraft")}</strong><small>{pendingDocument.summary?.title ?? pendingDocument.fileName}</small></span><ChevronRight size={15} /></button>}
            {latestDocument && <button className="today-row" onClick={() => navigate(`/vault?document=${latestDocument.id}`)}><span className="today-icon"><FileHeart size={16} /></span><span><strong>{w(language, "recentRecord")}</strong><small>{latestDocument.summary?.title ?? latestDocument.fileName} · {formatDate(latestDocument.uploadedAt)}</small></span><ChevronRight size={15} /></button>}
            {!upcoming && activeTasks.length === 0 && !latestMedication && !pendingDocument && <div className="empty-inline"><span><Check size={15} /></span><p>{t(language, "nothingAttention")}</p></div>}
          </div>
          <button className="inline-link" onClick={() => navigate("/profile")}>{t(language, "nextStepsLink")} <ArrowRight size={13} /></button>
        </div>

        <div className="home-panel journey-preview card">
          <div className="section-title"><div><span className="section-label">{w(language, "recentActivity")}</span><h2>{t(language, "journeyPreview")}</h2></div><Waypoints size={17} className="section-icon" /></div>
          {latestEvents.length ? <div className="mini-timeline">{latestEvents.map((event: JourneyEventSummary, index) => <div className="mini-timeline-row" key={event.id}><div className="mini-date">{formatDate(event.eventDate)}</div><div className="mini-track"><span className={index === 0 ? "current" : ""} /><i className={index < latestEvents.length - 1 ? "track" : ""} /></div><div className="mini-event"><strong>{event.title}</strong><small>{event.detail}{event.isDemo ? " · Synthetic" : ""}</small></div></div>)}</div> : <div className="empty-inline"><span><Waypoints size={15} /></span><p>{t(language, "noRecords")}</p></div>}
          <button className="inline-link" onClick={() => navigate("/journey")}>{t(language, "viewJourney")} <ArrowRight size={13} /></button>
        </div>
      </section>
      <p className="safety-note"><ShieldIcon />{t(language, "safety")}</p>
    </div>
  );
}

function ShieldIcon() { return <MessageCircleHeart size={14} aria-hidden="true" />; }
