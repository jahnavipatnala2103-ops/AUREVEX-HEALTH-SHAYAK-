import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { t } from "@/lib/i18n";
import { w } from "@/lib/workflowCopy";
import { trpc } from "@/lib/trpc";
import type { JourneyKind } from "@shared/health";
import { ArrowDownWideNarrow, ArrowUpWideNarrow, BadgeCheck, CalendarDays, Check, ClipboardList, FileHeart, HeartPulse, Pill, Stethoscope, Waypoints } from "lucide-react";
import { format } from "date-fns";

const filters = ["All", "Consultations", "Reports", "Medications", "Appointments", "Follow-ups"] as const;
type Filter = typeof filters[number];
const iconFor: Record<JourneyKind, typeof FileHeart> = { report: FileHeart, consultation: Stethoscope, medication: Pill, appointment: CalendarDays, follow_up: ClipboardList, insurance: BadgeCheck, discharge: HeartPulse, wellness: HeartPulse };
const filterKinds: Record<Exclude<Filter, "All">, JourneyKind[]> = { Consultations: ["consultation"], Reports: ["report"], Medications: ["medication"], Appointments: ["appointment"], "Follow-ups": ["follow_up"] };
const fmt = (date: string) => format(new Date(date), "MMM d, yyyy");
const eventLabel = (kind: JourneyKind, language: import("@shared/health").HealthLanguage) => kind === "report" ? w(language, "reports") : kind === "consultation" ? w(language, "consultations") : kind === "medication" ? w(language, "medications") : kind === "appointment" ? w(language, "appointments") : kind === "follow_up" ? w(language, "followUps") : kind === "insurance" ? w(language, "insuranceType") : kind === "discharge" ? w(language, "dischargeSummary") : w(language, "wellnessType");

export default function Journey() {
  const overview = trpc.health.overview.useQuery();
  const [, navigate] = useLocation();
  const language = overview.data?.profile.preferredLanguage ?? "en";
  const [filter, setFilter] = useState<Filter>("All");
  const [sort, setSort] = useState<"newest" | "oldest">("newest");
  const events = useMemo(() => {
    const data = overview.data?.events ?? [];
    const filtered = filter === "All" ? data : data.filter(event => filterKinds[filter].includes(event.kind));
    return [...filtered].sort((a, b) => sort === "newest" ? +new Date(b.eventDate) - +new Date(a.eventDate) : +new Date(a.eventDate) - +new Date(b.eventDate));
  }, [overview.data?.events, filter, sort]);

  return <div className="journey-page">
    <div className="page-heading"><div><p className="page-kicker">{w(language, "journeyKicker")}</p><h1>{w(language, "journeyTitle")}</h1><p>{w(language, "journeyDescription")}</p></div><div className="journey-summary-pill"><Waypoints size={15} />{overview.data?.events.length ?? 0} {w(language, "careMoments")}</div></div>
    <div className="journey-toolbar"><div className="filter-pills" role="tablist" aria-label={w(language, "filterJourney")}>{filters.map(option => <button key={option} role="tab" aria-selected={filter === option} className={filter === option ? "active" : ""} onClick={() => setFilter(option)}>{option === "All" ? t(language, "all") : w(language, option === "Consultations" ? "consultations" : option === "Reports" ? "reports" : option === "Medications" ? "medications" : option === "Appointments" ? "appointments" : "followUps")}</button>)}</div><button className="sort-button" onClick={() => setSort(sort === "newest" ? "oldest" : "newest")} aria-label={w(language, "changeSort")}>{sort === "newest" ? <ArrowDownWideNarrow size={14} /> : <ArrowUpWideNarrow size={14} />}{sort === "newest" ? t(language, "newest") : t(language, "oldest")}</button></div>
    <div className="journey-main">
      <div className="journey-timeline">
        {overview.isLoading && <div className="card loading-card">{w(language, "loadingJourney")}</div>}
        {overview.error && <div className="card error-panel">{w(language, "journeyError")}</div>}
        {!overview.isLoading && !overview.error && events.length === 0 && <div className="card journey-empty"><span><Waypoints size={24} /></span><h2>{filter === "All" ? w(language, "journeyEmpty") : w(language, "noMatchingEvents")}</h2><p>{w(language, "journeyEmptyDescription")}</p></div>}
        {events.map((event, index) => { const Icon = iconFor[event.kind]; return <article className="journey-event" key={event.id}><div className="journey-date-col"><time>{fmt(event.eventDate)}</time><small>{format(new Date(event.eventDate), "EEEE")}</small></div><div className="journey-track-col"><span className={`journey-dot ${index === 0 ? "latest" : ""}`}><Icon size={14} /></span>{index < events.length - 1 && <i />}</div><div className="journey-event-card card"><div className="journey-event-top"><div><span className="event-kind-label">{eventLabel(event.kind, language)}</span><h2>{event.title}</h2></div>{event.isDemo && <span className="demo-tag">{w(language, "syntheticTitle")}</span>}</div><p>{event.detail || w(language, "careEventFallback")}</p>{event.documentId ? <button className="inline-link" onClick={() => navigate(`/vault?document=${event.documentId}`)}><FileHeart size={13} />{w(language, "sourceRecord")} <span>#{event.recordId}</span></button> : event.recordId ? <span className="tiny muted">{w(language, "noSourceLink")}</span> : null}</div></article>; })}
      </div>
      <aside className="journey-aside card"><span className="aside-icon"><HeartPulse size={17} /></span><span className="section-label">{w(language, "connectedView")}</span><h2>{w(language, "connectedHeading")}</h2><p>{w(language, "connectedDescription")}</p><div className="aside-flow"><span>{w(language, "record")}</span><i /><span>{w(language, "profile")}</span><i /><span>{w(language, "journey")}</span></div><div className="aside-divider" /><div className="aside-safety"><Check size={13} /><span>{w(language, "confirmToJoin")}</span></div></aside>
    </div>
  </div>;
}
