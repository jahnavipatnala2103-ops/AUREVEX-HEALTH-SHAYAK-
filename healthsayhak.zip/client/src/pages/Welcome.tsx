import { useState } from "react";
import { useLocation } from "wouter";
import { ArrowRight, BadgeCheck, FileHeart, FileUp, ListChecks, ShieldCheck, Waypoints } from "lucide-react";
import { BrandMark } from "@/components/BrandMark";
import { entryText } from "@/lib/entryCopy";
import { websiteText } from "@/lib/websiteCopy";
import type { HealthLanguage } from "@shared/health";

const languages: { value: HealthLanguage; label: string }[] = [
  { value: "en", label: "English" },
  { value: "te", label: "తెలుగు" },
  { value: "hi", label: "हिन्दी" },
];

export default function Welcome({ error }: { error?: boolean }) {
  const [, navigate] = useLocation();
  const [language, setLanguage] = useState<HealthLanguage>("en");
  const copy = (key: Parameters<typeof entryText>[1]) => entryText(language, key);
  const webCopy = (key: Parameters<typeof websiteText>[1]) => websiteText(language, key);
  const steps = [
    { icon: FileUp, title: copy("stepOneTitle"), body: copy("stepOneBody") },
    { icon: ListChecks, title: copy("stepTwoTitle"), body: copy("stepTwoBody") },
    { icon: BadgeCheck, title: webCopy("flowConfirm"), body: copy("demoReviewBody") },
    { icon: Waypoints, title: webCopy("flowStepFourTitle"), body: webCopy("flowStepFourBody") },
    { icon: FileHeart, title: webCopy("flowStepFiveTitle"), body: webCopy("flowStepFiveBody") },
  ];

  return <main className="entry-screen">
    <header className="entry-header">
      <button className="entry-brand" type="button" onClick={() => navigate("/")} aria-label="HealthSahayak">
        <BrandMark /><span><strong>HealthSahayak</strong><small>{copy("brandLine")}</small></span>
      </button>
      <label className="entry-language"><span>{copy("language")}</span><select value={language} onChange={event => setLanguage(event.target.value as HealthLanguage)} aria-label={copy("language")}>{languages.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
    </header>

    <section className="entry-content">
      <div className="entry-hero">
        <p className="eyebrow">{copy("introEyebrow")}</p>
        <h1>{copy("introTitle")}</h1>
        <p className="entry-lede">{copy("introBody")}</p>
        <div className="entry-how">
          <h2>{webCopy("flowTitle")}</h2>
          <div className="entry-steps">
            {steps.map((step, index) => { const Icon = step.icon; return <article className="entry-step" key={step.title}><span className="entry-step-number">0{index + 1}</span><span className="entry-step-icon"><Icon size={18} /></span><h3>{step.title}</h3><p>{step.body}</p></article>; })}
          </div>
        </div>
      </div>

      <aside className="entry-choices" aria-label={copy("choosePath")}>
        <div className="entry-choice-heading"><span className="entry-choice-mark"><BrandMark /></span><p>HealthSahayak</p><h2>{copy("choosePath")}</h2></div>
        <button className="entry-choice entry-choice-primary" type="button" onClick={() => navigate(`/signin?lang=${language}`)}>
          <span><strong>{webCopy("emailChoice")}</strong><small>{webCopy("emailChoiceHint")}</small></span><ArrowRight size={19} />
        </button>
        <button className="entry-choice entry-choice-secondary" type="button" onClick={() => navigate(`/demo?lang=${language}`)}>
          <span><strong>{webCopy("demoChoice")}</strong><small>{webCopy("demoChoiceHint")}</small></span><ArrowRight size={19} />
        </button>
        {error && <p className="entry-error" role="alert">{copy("signInError")}</p>}
        <p className="entry-safety"><ShieldCheck size={15} />{copy("careNote")}</p>
        <button className="judge-link" type="button" onClick={() => navigate("/brief")}>{webCopy("judgeLink")}<ArrowRight size={14} /></button>
      </aside>
    </section>
    <footer className="entry-footer"><span>HealthSahayak</span><span>{copy("careNote")}</span></footer>
  </main>;
}
