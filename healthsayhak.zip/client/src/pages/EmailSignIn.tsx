import { useState } from "react";
import type { FormEvent } from "react";
import { ArrowLeft, ArrowRight, Mail, ShieldCheck } from "lucide-react";
import { useLocation } from "wouter";
import { BrandMark } from "@/components/BrandMark";
import { startLogin } from "@/const";
import { entryText } from "@/lib/entryCopy";
import { websiteText } from "@/lib/websiteCopy";
import { trpc } from "@/lib/trpc";
import type { HealthLanguage } from "@shared/health";

const languages: { value: HealthLanguage; label: string }[] = [
  { value: "en", label: "English" },
  { value: "te", label: "తెలుగు" },
  { value: "hi", label: "हिन्दी" },
];

function queryLanguage(): HealthLanguage {
  const value = new URLSearchParams(window.location.search).get("lang");
  return value === "te" || value === "hi" ? value : "en";
}

export default function EmailSignIn() {
  const [, navigate] = useLocation();
  const [language, setLanguage] = useState<HealthLanguage>(queryLanguage);
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [codeRequested, setCodeRequested] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const requestCode = trpc.auth.requestEmailCode.useMutation();
  const verifyCode = trpc.auth.verifyEmailCode.useMutation();
  const text = (key: Parameters<typeof websiteText>[1]) => websiteText(language, key);
  const copy = (key: Parameters<typeof entryText>[1]) => entryText(language, key);

  const requestSignInCode = async () => {
    setError("");
    setNotice("");
    try {
      const result = await requestCode.mutateAsync({ email: email.trim().toLowerCase() });
      if (!result.sent) {
        setError(`${text("cooldown")} (${result.retryAfterSeconds ?? 60}s)`);
        return;
      }
      setCodeRequested(true);
      setNotice(text("codeSent"));
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "";
      setError(/email|resend|delivery|temporary|unavailable/i.test(message) ? text("unavailable") : message || text("unavailable"));
    }
  };

  const sendCode = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    void requestSignInCode();
  };

  const verify = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError("");
    try {
      await verifyCode.mutateAsync({ email: email.trim().toLowerCase(), code: code.trim() });
      window.location.assign("/");
    } catch {
      setError(text("invalidCode"));
    }
  };

  const changeEmail = () => {
    setCodeRequested(false);
    setCode("");
    setError("");
    setNotice("");
  };

  return <main className="entry-screen email-signin-screen">
    <header className="entry-header">
      <button className="entry-brand" type="button" onClick={() => navigate("/")} aria-label="HealthSahayak"><BrandMark /><span><strong>HealthSahayak</strong><small>{copy("brandLine")}</small></span></button>
      <label className="entry-language"><span>{copy("language")}</span><select value={language} onChange={event => setLanguage(event.target.value as HealthLanguage)} aria-label={copy("language")}>{languages.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
    </header>
    <section className="email-signin-wrap">
      <div className="email-signin-card">
        <span className="email-signin-icon"><Mail size={22} /></span>
        <p className="eyebrow">HealthSahayak</p>
        <h1>{text("emailTitle")}</h1>
        <p className="email-signin-intro">{text("emailIntro")}</p>
        {!codeRequested ? <form className="email-auth-form" onSubmit={sendCode}>
          <label>{text("emailLabel")}<input type="email" autoComplete="email" maxLength={320} required value={email} onChange={event => setEmail(event.target.value)} placeholder="you@example.com" /></label>
          <button className="button button-primary email-auth-submit" type="submit" disabled={requestCode.isPending}>{requestCode.isPending ? text("sending") : text("sendCode")}<ArrowRight size={16} /></button>
        </form> : <form className="email-auth-form" onSubmit={event => void verify(event)}>
          <p className="email-recipient">{email.trim().toLowerCase()}</p>
          <label>{text("codeLabel")}<input type="text" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} required value={code} onChange={event => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="000000" /></label>
          <button className="button button-primary email-auth-submit" type="submit" disabled={verifyCode.isPending || code.length !== 6}>{verifyCode.isPending ? text("verifying") : text("verifyCode")}<ArrowRight size={16} /></button>
          <button className="email-text-button" type="button" onClick={changeEmail}>{text("changeEmail")}</button>
          <button className="email-text-button" type="button" disabled={requestCode.isPending} onClick={() => void requestSignInCode()}>{requestCode.isPending ? text("sending") : text("resendCode")}</button>
        </form>}
        {notice && <p className="email-status-note" role="status" aria-live="polite">{notice}</p>}
        {error && <p className="email-error-note" role="alert">{error}</p>}
        <p className="email-privacy-note"><ShieldCheck size={15} />{text("emailPrivacy")}</p>
        <div className="email-separator"><span>{language === "te" ? "లేదా" : language === "hi" ? "या" : "or"}</span></div>
        <button className="button button-secondary email-auth-submit" type="button" onClick={() => startLogin()}>{text("manusFallback")}</button>
        <button className="email-back-link" type="button" onClick={() => navigate("/")}><ArrowLeft size={14} />{text("backWelcome")}</button>
      </div>
    </section>
    <footer className="entry-footer"><span>HealthSahayak</span><span>{copy("careNote")}</span></footer>
  </main>;
}
