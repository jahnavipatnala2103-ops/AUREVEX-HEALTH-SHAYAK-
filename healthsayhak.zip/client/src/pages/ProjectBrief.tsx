import { ArrowLeft, ArrowRight, ShieldCheck } from "lucide-react";
import { useLocation } from "wouter";
import { BrandMark } from "@/components/BrandMark";

const brief = [
  {
    question: "What problem are you solving?",
    answer: "Medical information is commonly split across reports, prescriptions, discharge papers and separate visits. People are then asked to reconstruct their story from memory. HealthSahayak brings those records into one patient-controlled journey.",
  },
  {
    question: "Why this idea, and why does it matter?",
    answer: "The idea starts from an everyday need: make health information easier to find, understand and carry into the next conversation. Clear records can help people prepare and follow up; the app does not promise a clinical outcome.",
  },
  {
    question: "What makes it different from a chatbot or file vault?",
    answer: "The core loop is document → user-reviewed facts → connected profile and timeline → Copilot response with source records and dates. HealthSahayak aims to answer in context, not just return a generic answer or store a file.",
  },
  {
    question: "What is the technical stack?",
    answer: "Frontend: React 19, TypeScript, Vite and responsive CSS. Backend: Node.js, Express and tRPC. Persistence: Drizzle ORM with managed MySQL plus managed object storage for private source files. AI: the managed multimodal LLM for extraction and contextual explanations; speech-to-text is a separate managed service. Email sign-in uses Resend when a verified sender and server-side key are configured.",
  },
  {
    question: "How is it deployed?",
    answer: "The application runs on the Manus-managed Webdev server and managed database. The current delivery is a live Cloud Preview and saved project checkpoint, not a public production release. Publication is a separate deployment step.",
  },
  {
    question: "How are privacy and clinical safety handled?",
    answer: "Private records are scoped to the signed-in owner; uploaded source access is checked server-side. Extracted facts require user review and confirmation before saving. Copilot citations are tied to authorized records. It does not diagnose or prescribe, and the project does not claim HIPAA certification or clinical validation.",
  },
  {
    question: "What could scale next, and what is not live yet?",
    answer: "The data model is arranged to map to FHIR-style Patient, Observation, Medication, Encounter and DiagnosticReport resources. Future work could add clinical evaluation, vetted care-provider workflows and standards-based connections. There is no live ABDM/ABHA integration, no health-system partnership claim and no clinician outcome study in this build.",
  },
  {
    question: "Why use HealthSahayak?",
    answer: "It gives the person a simpler place to organize records, see what is confirmed, follow the timeline, and ask questions whose supporting records remain visible. The patient remains in control of what is saved and shared.",
  },
];

export default function ProjectBrief() {
  const [, navigate] = useLocation();
  return <main className="entry-screen judge-screen">
    <header className="entry-header">
      <button className="entry-brand" type="button" onClick={() => navigate("/")} aria-label="HealthSahayak"><BrandMark /><span><strong>HealthSahayak</strong><small>FOR JUDGES · AUREBECKS</small></span></button>
      <button className="button button-secondary button-small" onClick={() => navigate("/")}><ArrowLeft size={15} />Back to welcome</button>
    </header>
    <section className="judge-content">
      <p className="eyebrow">THE IDEA, THE BUILD, THE BOUNDARIES</p>
      <h1>From scattered records to an explained health journey.</h1>
      <p className="judge-lede">HealthSahayak is a personal health information organizer that connects a person's records to a source-aware Copilot—while keeping review and confirmation with the person.</p>
      <div className="judge-differentiator"><ShieldCheck size={18} /><p><strong>Our difference:</strong> not just “upload and ask.” Each answer can point back to the record and date; extracted information joins the journey only after the user confirms it.</p></div>
      <div className="judge-stack-strip"><span>React 19 · TypeScript · Vite</span><span>Node.js · Express · tRPC</span><span>Drizzle · Managed MySQL</span><span>Managed AI · Webdev Cloud Preview</span></div>
      <section className="judge-questions" aria-label="Hackathon judge questions">
        {brief.map(item => <article key={item.question} className="judge-answer"><h2>{item.question}</h2><p>{item.answer}</p></article>)}
      </section>
      <div className="judge-actions"><button className="button button-secondary" onClick={() => navigate("/demo")} >Explore the read-only demo<ArrowRight size={15} /></button><button className="button button-primary" onClick={() => navigate("/signin")} >Sign in with email<ArrowRight size={15} /></button></div>
    </section>
    <footer className="entry-footer"><span>HealthSahayak · AUREBECKS</span><span>Health information is not a diagnosis or a substitute for professional care.</span></footer>
  </main>;
}
