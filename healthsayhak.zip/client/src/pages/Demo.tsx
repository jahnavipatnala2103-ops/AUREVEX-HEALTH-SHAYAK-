import { useState } from "react";
import type { FormEvent } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, ArrowRight, Check, FileHeart, FileText, HeartPulse, ShieldCheck, Waypoints } from "lucide-react";
import { BrandMark } from "@/components/BrandMark";
import { entryText } from "@/lib/entryCopy";
import { websiteText } from "@/lib/websiteCopy";
import type { HealthLanguage } from "@shared/health";

const DEMO_EMAIL = "demo@healthsayhak.test";
const DEMO_PASSWORD = "HealthSahayak-demo";
const languages: { value: HealthLanguage; label: string }[] = [
  { value: "en", label: "English" },
  { value: "te", label: "తెలుగు" },
  { value: "hi", label: "हिन्दी" },
];
const sample = [
  { key: "hemoglobin" as const, result: "12.4 g/dL", range: "12.0–15.5 g/dL", outside: false },
  { key: "glucose" as const, result: "102 mg/dL", range: "70–99 mg/dL", outside: true },
  { key: "whiteBloodCells" as const, result: "6.1 ×10³/µL", range: "4.0–11.0 ×10³/µL", outside: false },
];

export default function Demo() {
  const [, navigate] = useLocation();
  const queryLanguage = new URLSearchParams(window.location.search).get("lang");
  const initialLanguage: HealthLanguage = queryLanguage === "te" || queryLanguage === "hi" ? queryLanguage : "en";
  const [language, setLanguage] = useState<HealthLanguage>(initialLanguage);
  const [demoEmail, setDemoEmail] = useState(DEMO_EMAIL);
  const [demoPassword, setDemoPassword] = useState(DEMO_PASSWORD);
  const [demoError, setDemoError] = useState(false);
  const [authorized, setAuthorized] = useState(false);
  const [step, setStep] = useState(0);
  const copy = (key: Parameters<typeof entryText>[1]) => entryText(language, key);
  const webCopy = (key: Parameters<typeof websiteText>[1]) => websiteText(language, key);
  const steps = [copy("demoStep1"), copy("demoStep2"), copy("demoStep3"), copy("demoStep4")];
  const login = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const valid = demoEmail.trim().toLowerCase() === DEMO_EMAIL && demoPassword === DEMO_PASSWORD;
    setAuthorized(valid);
    setDemoError(!valid);
  };

  return <main className="demo-screen">
    <header className="entry-header demo-header">
      <button className="entry-brand" onClick={() => navigate("/")} aria-label={copy("backIntro")}><BrandMark /><span><strong>HealthSahayak</strong><small>{copy("brandLine")}</small></span></button>
      <div className="demo-header-actions"><label className="entry-language"><span>{copy("language")}</span><select value={language} onChange={event => { const next = event.target.value as HealthLanguage; setLanguage(next); window.history.replaceState(null, "", `/demo?lang=${next}`); }} aria-label={copy("language")}>{languages.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label><button className="button button-primary button-small" onClick={() => navigate(`/signin?lang=${language}`)}>{webCopy("emailChoice")}</button></div>
    </header>

    {!authorized ? <section className="demo-login-page">
      <div className="demo-login-card">
        <span className="entry-choice-mark"><BrandMark /></span>
        <p className="eyebrow">{copy("demoEyebrow")}</p>
        <h1>{webCopy("demoTitle")}</h1>
        <p className="demo-lede">{webCopy("demoIntro")}</p>
        <div className="demo-credentials"><strong>{webCopy("demoCredentials")}</strong><span><code>{DEMO_EMAIL}</code><code>{DEMO_PASSWORD}</code></span></div>
        <form className="email-auth-form demo-login-form" onSubmit={login}>
          <label>{webCopy("demoEmail")}<input type="email" autoComplete="off" value={demoEmail} onChange={event => setDemoEmail(event.target.value)} required /></label>
          <label>{webCopy("demoPassword")}<input type="password" autoComplete="off" value={demoPassword} onChange={event => setDemoPassword(event.target.value)} required /></label>
          {demoError && <p role="alert" className="demo-login-error">{webCopy("demoInvalid")}</p>}
          <button className="button button-primary email-auth-submit" type="submit">{webCopy("demoSubmit")}<ArrowRight size={16} /></button>
        </form>
        <p className="email-privacy-note"><ShieldCheck size={15} />{webCopy("demoNotice")}</p>
        <div className="demo-login-links"><button className="email-text-button" onClick={() => navigate("/")}>{webCopy("backWelcome")}</button><button className="email-text-button" onClick={() => navigate("/brief")}>{webCopy("openProjectBrief")}</button></div>
      </div>
    </section> : <>
      <section className="demo-content">
        <div className="demo-intro-row"><div><p className="eyebrow">{copy("demoEyebrow")} <span className="demo-synthetic-pill">{copy("demoSampleLabel")}</span></p><h1>{copy("demoTitle")}</h1><p className="demo-lede">{copy("demoIntro")}</p></div><button className="button button-secondary button-small" onClick={() => setAuthorized(false)}>{webCopy("demoExit")}</button></div>
        <div className="demo-stepper" aria-label={copy("demoEyebrow")}>{steps.map((item, index) => <button key={item} className={index === step ? "active" : index < step ? "complete" : ""} onClick={() => setStep(index)} aria-current={index === step ? "step" : undefined}><i>{index < step ? <Check size={14} /> : index + 1}</i><span>{item}</span></button>)}</div>

        <article className="demo-panel card">
          {step === 0 && <div className="demo-report-view">
            <div className="demo-report-heading"><span className="demo-icon"><FileText size={21} /></span><div><h2>{copy("demoReportTitle")}</h2><p>{copy("demoDate")}</p></div><span className="demo-synthetic-pill">{copy("demoSampleLabel")}</span></div>
            <section className="demo-vault-shelf"><div className="demo-vault-heading"><FileHeart size={18} /><div><h3>{webCopy("vaultTitle")}</h3><p>{webCopy("vaultCaption")}</p></div></div>
              <div className="demo-vault-docs">{[
                { name: webCopy("sampleReport"), type: webCopy("typeReport"), date: webCopy("sampleReportDate") },
                { name: webCopy("samplePrescription"), type: webCopy("typePrescription"), date: webCopy("samplePrescriptionDate") },
                { name: webCopy("sampleNote"), type: webCopy("typeNote"), date: webCopy("sampleNoteDate") },
                { name: webCopy("sampleDischarge"), type: webCopy("typeDischarge"), date: webCopy("sampleDischargeDate") },
              ].map(item => <div className="demo-vault-doc" key={item.name}><FileText size={17} /><div><strong>{item.name}</strong><span>{item.type} · {item.date}</span></div><span className="demo-vault-tag">{copy("demoSampleLabel")}</span></div>)}</div>
            </section>
            <div className="demo-table-wrap"><table className="demo-results"><caption>{copy("demoValues")}</caption><thead><tr><th>{copy("test")}</th><th>{copy("result")}</th><th>{copy("referenceRange")}</th><th>{copy("status")}</th></tr></thead><tbody>{sample.map(item => <tr key={item.key}><th>{copy(item.key)}</th><td>{item.result}</td><td>{item.range}</td><td><span className={item.outside ? "range-status warning" : "range-status"}>{item.outside ? copy("outsideRange") : copy("withinRange")}</span></td></tr>)}</tbody></table></div>
            <div className="demo-disclaimer"><ShieldCheck size={15} /><p>{copy("rangeDisclaimer")}</p></div>
          </div>}
          {step === 1 && <div className="demo-review-view"><span className="demo-icon"><ShieldCheck size={21} /></span><p className="section-label">{copy("demoStep2")}</p><h2>{copy("demoReviewTitle")}</h2><p>{copy("demoReviewBody")}</p><div className="demo-review-summary"><strong>{copy("demoValues")}</strong>{sample.map(item => <div key={item.key}><span><Check size={14} />{copy(item.key)}</span><strong>{item.result}</strong></div>)}</div><div className="demo-disclaimer"><HeartPulse size={15} /><p>{copy("demoNoPersonalData")}</p></div></div>}
          {step === 2 && <div className="demo-answer-view"><p className="section-label">{copy("demoAnswerLabel")}</p><div className="demo-question">{copy("demoQuestion")}</div><div className="demo-answer"><span className="chat-avatar"><HeartPulse size={17} /></span><div><strong>HealthSahayak</strong><p>{copy("demoAnswer")}</p></div></div><details className="demo-evidence"><summary><FileHeart size={14} />{copy("demoEvidence")}</summary><p>{copy("demoNoPersonalData")}</p></details></div>}
          {step === 3 && <div className="demo-journey-view"><span className="demo-icon"><Waypoints size={21} /></span><p className="section-label">{copy("demoStep4")}</p><h2>{copy("demoJourneyTitle")}</h2><div className="demo-destinations"><div><FileHeart size={17} /><span><strong>{copy("demoVault")}</strong><small>{copy("demoReportTitle")}</small></span><Check size={15} /></div><div><HeartPulse size={17} /><span><strong>{copy("demoProfile")}</strong><small>{copy("onlyConfirmed")}</small></span><Check size={15} /></div><div><Waypoints size={17} /><span><strong>{copy("demoJourney")}</strong><small>{copy("demoDate")}</small></span><Check size={15} /></div><div><ShieldCheck size={17} /><span><strong>{copy("demoContext")}</strong><small>{copy("demoEvidence")}</small></span><Check size={15} /></div></div><p className="demo-read-only"><ShieldCheck size={15} />{webCopy("demoNotice")}</p></div>}
        </article>

        <nav className="demo-controls" aria-label={copy("demoEyebrow")}><button className="button button-secondary" onClick={() => step === 0 ? setAuthorized(false) : setStep(value => Math.max(0, value - 1))}>{step === 0 ? <><ArrowLeft size={15} />{webCopy("demoExit")}</> : <><ArrowLeft size={15} />{copy("previous")}</>}</button><div className="demo-dots">{steps.map((item, index) => <button key={item} className={index === step ? "active" : ""} aria-label={`${index + 1}: ${item}`} aria-current={index === step ? "step" : undefined} onClick={() => setStep(index)} />)}</div>{step < 3 ? <button className="button button-primary" onClick={() => setStep(value => Math.min(3, value + 1))}>{copy("next")}<ArrowRight size={15} /></button> : <button className="button button-primary" onClick={() => navigate(`/signin?lang=${language}`)}>{webCopy("emailChoice")}<ArrowRight size={15} /></button>}</nav>
      </section>
    </>}
    <footer className="entry-footer"><span>HealthSahayak</span><span>{copy("demoNoPersonalData")}</span></footer>
  </main>;
}
