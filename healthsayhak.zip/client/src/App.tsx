import { useAuth } from "@/_core/hooks/useAuth";
import { AppShell } from "@/components/AppShell";
import { BrandMark } from "@/components/BrandMark";
import { TooltipProvider } from "@/components/ui/tooltip";
import { trpc } from "@/lib/trpc";
import Copilot from "@/pages/Copilot";
import Demo from "@/pages/Demo";
import EmailSignIn from "@/pages/EmailSignIn";
import HealthVault from "@/pages/HealthVault";
import Home from "@/pages/Home";
import Journey from "@/pages/Journey";
import NotFound from "@/pages/NotFound";
import Onboarding from "@/pages/Onboarding";
import ProjectBrief from "@/pages/ProjectBrief";
import Profile from "@/pages/Profile";
import Welcome from "@/pages/Welcome";
import { Toaster } from "@/components/ui/sonner";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";

function LoadingScreen() {
  return <div className="auth-screen" role="status" aria-live="polite"><div className="auth-loading-mark"><BrandMark /></div><span className="loading-dot" /><p>Preparing your health space…</p></div>;
}

function ProfileErrorScreen() {
  return <main className="auth-screen"><section className="auth-card"><BrandMark className="auth-logo" /><h1>Your health space couldn’t load.</h1><p className="auth-lede">Your information has not been changed. Check your connection and try again.</p><button className="button button-primary auth-login" onClick={() => window.location.reload()}>Try again</button></section></main>;
}

function SignedInApp() {
  const auth = useAuth();
  const [location] = useLocation();
  const overview = trpc.health.overview.useQuery(undefined, { enabled: !!auth.user, retry: false });

  if (location === "/demo" || location.startsWith("/demo?")) return <Demo />;
  if (location === "/signin" || location.startsWith("/signin?")) return <EmailSignIn />;
  if (location === "/brief") return <ProjectBrief />;
  if (auth.loading) return <LoadingScreen />;
  if (!auth.user) return <Welcome error={Boolean(auth.error)} />;
  if (overview.isLoading || !overview.data && !overview.error) return <LoadingScreen />;
  if (overview.error || !overview.data) return <ProfileErrorScreen />;
  if (!overview.data.profile.onboardingCompleted) return <Onboarding profile={overview.data.profile} />;

  return <AppShell user={auth.user} onSignOut={auth.logout}>
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/copilot" component={Copilot} />
      <Route path="/vault" component={HealthVault} />
      <Route path="/journey" component={Journey} />
      <Route path="/profile" component={Profile} />
      <Route component={NotFound} />
    </Switch>
  </AppShell>;
}

export default function App() {
  return <ErrorBoundary><TooltipProvider><Toaster position="top-right" /><SignedInApp /></TooltipProvider></ErrorBoundary>;
}
